`include "defines.v"

module alu
(
    input  wire [31:0] operand_a,
    input  wire [31:0] operand_b,
    input  wire [3:0]  alu_ctrl,

    output reg  [31:0] result,
    output wire        zero,
    output reg         overflow
);

wire signed [31:0] s_operand_a;
wire signed [31:0] s_operand_b;

assign s_operand_a = operand_a;
assign s_operand_b = operand_b;

always @(*)
begin

    result   = 32'd0;
    overflow = 1'b0;

    case(alu_ctrl)

    //---------------------------------------------
    // ADD
    //---------------------------------------------
    `ALU_ADD:
    begin
        result = operand_a + operand_b;

        overflow =
            (~operand_a[31] & ~operand_b[31] & result[31]) |
            ( operand_a[31] &  operand_b[31] & ~result[31]);
    end

    //---------------------------------------------
    // SUB
    //---------------------------------------------
    `ALU_SUB:
    begin
        result = operand_a - operand_b;

        overflow =
            (~operand_a[31] & operand_b[31] & result[31]) |
            ( operand_a[31] & ~operand_b[31] & ~result[31]);
    end

    //---------------------------------------------
    // AND
    //---------------------------------------------
    `ALU_AND:
        result = operand_a & operand_b;

    //---------------------------------------------
    // OR
    //---------------------------------------------
    `ALU_OR:
        result = operand_a | operand_b;

    //---------------------------------------------
    // XOR
    //---------------------------------------------
    `ALU_XOR:
        result = operand_a ^ operand_b;

    //---------------------------------------------
    // Signed Less Than
    //---------------------------------------------
    `ALU_SLT:
        result = (s_operand_a < s_operand_b) ? 32'd1 : 32'd0;

    //---------------------------------------------
    // Unsigned Less Than
    //---------------------------------------------
    `ALU_SLTU:
        result = (operand_a < operand_b) ? 32'd1 : 32'd0;

    //---------------------------------------------
    // Shift Left Logical
    //---------------------------------------------
    `ALU_SLL:
        result = operand_a << operand_b[4:0];

    //---------------------------------------------
    // Shift Right Logical
    //---------------------------------------------
    `ALU_SRL:
        result = operand_a >> operand_b[4:0];

    //---------------------------------------------
    // Shift Right Arithmetic
    //---------------------------------------------
    `ALU_SRA:
        result = s_operand_a >>> operand_b[4:0];

    //---------------------------------------------
    // Default
    //---------------------------------------------
    default:
        result = 32'd0;

    endcase

end

//---------------------------------------------
// Zero Flag
//---------------------------------------------
assign zero = (result == 32'd0);

endmodule
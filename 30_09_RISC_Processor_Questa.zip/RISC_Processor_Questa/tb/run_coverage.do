# ============================================================
# Questa + Cocotb coverage script
# ============================================================

# Run the Cocotb test
run -all

# Create coverage directory
file mkdir coverage
file mkdir coverage/ucdb

# Save UCDB
puts "============================================================"
puts "Saving coverage to:"
puts $env(UCDB_FILE)
puts "============================================================"

coverage save $env(UCDB_FILE)

# Print coverage summary
coverage report -summary

puts "============================================================"
puts "Coverage saved successfully"
puts "============================================================"

quit -f
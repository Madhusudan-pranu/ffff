module register_file
(
    input  wire         clk,
    input  wire         rst,

    // Read Port 1
    input  wire [4:0]   rs1_addr,
    output wire [31:0]  rs1_data,

    // Read Port 2
    input  wire [4:0]   rs2_addr,
    output wire [31:0]  rs2_data,

    // Write Port
    input  wire         reg_write,
    input  wire [4:0]   rd_addr,
    input  wire [31:0]  rd_data
);

reg [31:0] reg_file [0:31];

integer i;

//---------------------------------------------
// Reset & Write
//---------------------------------------------
always @(posedge clk)
begin
    if (rst)
    begin
        for(i = 0; i < 32; i = i + 1)
            reg_file[i] <= 32'd0;
    end
    else if(reg_write)
    begin
        // x0 is always zero
        if(rd_addr != 5'd0)
            reg_file[rd_addr] <= rd_data;
    end
end

//---------------------------------------------
// Read Port 1
//---------------------------------------------
assign rs1_data = (rs1_addr == 5'd0) ?
                  32'd0 :
                  reg_file[rs1_addr];

//---------------------------------------------
// Read Port 2
//---------------------------------------------
assign rs2_data = (rs2_addr == 5'd0) ?
                  32'd0 :
                  reg_file[rs2_addr];

endmodule
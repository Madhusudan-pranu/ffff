`include "defines.v"

module immediate_generator
(
    input  wire [31:0] instruction,
    output reg  [31:0] immediate
);

wire [6:0] opcode;

assign opcode = instruction[6:0];

always @(*)
begin

    case(opcode)

    //------------------------------------------
    // I-Type
    //------------------------------------------
    `OPCODE_ITYPE,
    `OPCODE_LOAD,
    `OPCODE_JALR:
    begin
        immediate = {{20{instruction[31]}},
                      instruction[31:20]};
    end

    //------------------------------------------
    // S-Type
    //------------------------------------------
    `OPCODE_STORE:
    begin
        immediate = {{20{instruction[31]}},
                      instruction[31:25],
                      instruction[11:7]};
    end

    //------------------------------------------
    // B-Type
    //------------------------------------------
    `OPCODE_BRANCH:
    begin
        immediate = {{19{instruction[31]}},
                     instruction[31],
                     instruction[7],
                     instruction[30:25],
                     instruction[11:8],
                     1'b0};
    end

    //------------------------------------------
    // U-Type
    //------------------------------------------
    `OPCODE_LUI,
    `OPCODE_AUIPC:
    begin
        immediate = {instruction[31:12],
                     12'b0};
    end

    //------------------------------------------
    // J-Type
    //------------------------------------------
    `OPCODE_JAL:
    begin
        immediate = {{11{instruction[31]}},
                     instruction[31],
                     instruction[19:12],
                     instruction[20],
                     instruction[30:21],
                     1'b0};
    end

    //------------------------------------------
    // Default
    //------------------------------------------
    default:
        immediate = 32'd0;

    endcase

end

endmodule
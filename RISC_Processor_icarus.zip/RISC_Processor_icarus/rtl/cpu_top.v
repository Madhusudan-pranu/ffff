`timescale 1ns/1ps

module cpu_top
(
    input  wire clk,
    input  wire rst
);

    //------------------------------------------------------------
    // IF Stage Signals
    //------------------------------------------------------------
    wire [31:0] pc_current;
    wire [31:0] pc_next;
    wire [31:0] pc_plus4;
    wire [31:0] if_instruction;
    //------------------------------------------------------------
    // IF/ID Pipeline Register
    //------------------------------------------------------------
    wire [31:0] id_pc;
    wire [31:0] id_instruction;
    //------------------------------------------------------------
    // Register File
    //------------------------------------------------------------
    wire [ 4:0] rs1_addr;
    wire [ 4:0] rs2_addr;
    wire [ 4:0] rd_addr;
    wire [31:0] rs1_data;
    wire [31:0] rs2_data;
    //------------------------------------------------------------
    // Instruction Decode
    //------------------------------------------------------------
    wire [31:0] id_immediate;
    wire [ 6:0] opcode;
    wire [ 2:0] funct3;
    wire [ 6:0] funct7;
    //------------------------------------------------------------
    // Control Signals (ID Stage)
    //------------------------------------------------------------
    wire        id_reg_write;
    wire        id_mem_read;
    wire        id_mem_write;
    wire        id_mem_to_reg;
    wire        id_alu_src;
    wire        id_branch;
    wire        id_jump;
    wire [ 1:0] id_alu_op;
    //------------------------------------------------------------
    // Hazard Detection
    //------------------------------------------------------------
    wire        pc_write;
    wire        if_id_write;
    wire        id_ex_flush;
    //------------------------------------------------------------
    // ID/EX Pipeline Register
    //------------------------------------------------------------
    wire [31:0] ex_pc;
    wire [31:0] ex_rs1_data;
    wire [31:0] ex_rs2_data;
    wire [31:0] ex_imm;
    wire [ 4:0] ex_rs1;
    wire [ 4:0] ex_rs2;
    wire [ 4:0] ex_rd;
    wire [ 2:0] ex_funct3;
    wire [ 6:0] ex_funct7;
    wire        ex_reg_write;
    wire        ex_mem_read;
    wire        ex_mem_write;
    wire        ex_mem_to_reg;
    wire        ex_alu_src;
    wire        ex_branch;
    wire        ex_jump;
    wire [ 1:0] ex_alu_op;
    //------------------------------------------------------------
    // Execute Stage
    //------------------------------------------------------------
    wire [ 3:0] ex_alu_ctrl;
    wire [31:0] alu_result;
    wire        alu_zero;
    wire [31:0] ex_branch_addr;
    wire        branch_taken;
    //------------------------------------------------------------
    // Forwarding
    //------------------------------------------------------------
    wire [ 1:0] forward_a;
    wire [ 1:0] forward_b;
    reg  [31:0] alu_operand_a;
    reg  [31:0] alu_operand_b_reg;
    wire [31:0] alu_operand_b;
    //------------------------------------------------------------
    // EX/MEM Pipeline Register
    //------------------------------------------------------------
    wire [31:0] mem_alu_result;
    wire [31:0] mem_write_data;
    wire [31:0] mem_branch_addr;
    wire        mem_zero;
    wire [ 4:0] mem_rd;
    wire        mem_reg_write;
    wire        mem_mem_read;
    wire        mem_mem_write;
    wire        mem_mem_to_reg;
    wire        mem_branch;
    wire        mem_jump;
    // Required for Data Memory
    // Add this signal only if ex_mem_reg pipelines funct3.
    wire [ 2:0] mem_funct3;
    //------------------------------------------------------------
    // Data Memory
    //------------------------------------------------------------
    wire [31:0] mem_read_data;
    //------------------------------------------------------------
    // MEM/WB Pipeline Register
    //------------------------------------------------------------
    wire [31:0] wb_alu_result;
    wire [31:0] wb_memory_data;
    wire [ 4:0] wb_rd;
    wire        wb_reg_write;
    wire        wb_mem_to_reg;
    //------------------------------------------------------------
    // Write Back
    //------------------------------------------------------------
    wire [31:0] wb_data;
	wire [31:0] ex_instruction;
    wire [31:0] mem_instruction;
    wire [31:0] wb_instruction;
	wire [31:0] wb_pc;
    //------------------------------------------------------------
    // PC Write Control
    //------------------------------------------------------------
    // Hazard Detection Unit generates:
    // pc_write = 1 -> Update PC
    // pc_write = 0 -> Stall PC
    wire   pc_enable;
    assign pc_enable = pc_write;
    //------------------------------------------------------------
    // PC + 4
    //------------------------------------------------------------
    assign pc_plus4 = pc_current + 32'd4;
    //------------------------------------------------------------
    // Next PC Logic
    //------------------------------------------------------------
    // Branch target generated in Execute stage
    assign pc_next =((ex_branch && branch_taken) || ex_jump) ?
                     ex_branch_addr : pc_plus4;
    //------------------------------------------------------------
    // Program Counter
    //------------------------------------------------------------
    pc U_PC (
    .clk        (clk        ),
    .rst        (rst        ),
    .pc_write   (pc_enable  ),
    .next_pc    (pc_next    ),
    .pc         (pc_current ));

    //------------------------------------------------------------
    // Instruction Memory
    //------------------------------------------------------------
    instruction_memory U_IMEM (
    .address     (pc_current    ),
    .instruction (if_instruction));

    //------------------------------------------------------------
    // IF/ID Pipeline Register
    //------------------------------------------------------------
    if_id_reg U_IF_ID (
    .clk            (clk           ),
    .rst            (rst           ),
    // Stall
    .stall          (~if_id_write  ),
    // Flush
    .flush          ((ex_branch && branch_taken) || ex_jump),
    // Inputs
    .pc_in          (pc_current    ),
    .instruction_in (if_instruction),
    // Outputs
    .pc_out         (id_pc         ),
    .instruction_out(id_instruction));
    
    //------------------------------------------------------------
    // Instruction Decode Fields
    //------------------------------------------------------------
    assign opcode   = id_instruction[6:0];
    assign rd_addr  = id_instruction[11:7];
    assign funct3   = id_instruction[14:12];
    assign rs1_addr = id_instruction[19:15];
    assign rs2_addr = id_instruction[24:20];
    assign funct7   = id_instruction[31:25];
    //------------------------------------------------------------
    // Register File
    //------------------------------------------------------------
    register_file U_REGISTER_FILE (
    .clk        (clk               ),
    .rst        (rst               ),
    // Read Port 1
    .rs1_addr   (rs1_addr          ),
    .rs1_data   (rs1_data          ),
    // Read Port 2
    .rs2_addr   (rs2_addr          ),
    .rs2_data   (rs2_data          ),
    // Write Back Port
    .reg_write  (wb_reg_write      ),
    .rd_addr    (wb_rd             ),
    .rd_data    (wb_data           ));

    //------------------------------------------------------------
    // Immediate Generator
    //------------------------------------------------------------
    immediate_generator U_IMM_GEN (
    .instruction    (id_instruction),
    .immediate      (id_immediate  ));

    //------------------------------------------------------------
    // Main Control Unit
    //------------------------------------------------------------
    control_unit U_CONTROL
    (
    .opcode         (opcode        ),
    .reg_write      (id_reg_write  ),
    .mem_read       (id_mem_read   ),
    .mem_write      (id_mem_write  ),
    .mem_to_reg     (id_mem_to_reg ),
    .alu_src        (id_alu_src    ),
    .branch         (id_branch     ),
    .jump           (id_jump       ),
    .alu_op         (id_alu_op     ));

    //------------------------------------------------------------
    // Hazard Detection Unit
    //------------------------------------------------------------
    hazard_detection_unit U_HAZARD (
    .id_ex_mem_read (ex_mem_read   ),
    .id_ex_rd       (ex_rd         ),
    .if_id_rs1      (rs1_addr      ),
    .if_id_rs2      (rs2_addr      ),
    .pc_write       (pc_write      ),
    .if_id_write    (if_id_write   ),
    .id_ex_flush    (id_ex_flush   ));

    //------------------------------------------------------------
    // ID/EX Pipeline Register
    //------------------------------------------------------------
    id_ex_reg U_ID_EX (
    .clk             (clk          ),
    .rst             (rst          ),
    .flush           (id_ex_flush  ),
    // Data
    .pc_in           (id_pc        ),
    .rs1_data_in     (rs1_data     ),
    .rs2_data_in     (rs2_data     ),
    .imm_in          (id_immediate ),
    .rs1_in          (rs1_addr     ),
    .rs2_in          (rs2_addr     ),
    .rd_in           (rd_addr      ),
    .funct3_in       (funct3       ),
    .funct7_in       (funct7       ),
    // Control
    .reg_write_in    (id_reg_write ),
    .mem_read_in     (id_mem_read  ),
    .mem_write_in    (id_mem_write ),
    .mem_to_reg_in   (id_mem_to_reg),
    .alu_src_in      (id_alu_src   ),
    .branch_in       (id_branch    ),
    .jump_in         (id_jump      ),
    .alu_op_in       (id_alu_op    ),
    // Outputs
    .pc_out          (ex_pc        ),
    .rs1_data_out    (ex_rs1_data  ),
    .rs2_data_out    (ex_rs2_data  ),
    .imm_out         (ex_imm       ),
    .rs1_out         (ex_rs1       ),
    .rs2_out         (ex_rs2       ),
    .rd_out          (ex_rd        ),
    .funct3_out      (ex_funct3    ),
    .funct7_out      (ex_funct7    ),
    .reg_write_out   (ex_reg_write ),
    .mem_read_out    (ex_mem_read  ),
    .mem_write_out   (ex_mem_write ),
    .mem_to_reg_out  (ex_mem_to_reg),
    .alu_src_out     (ex_alu_src   ),
    .branch_out      (ex_branch    ),
    .jump_out        (ex_jump      ),
    .alu_op_out      (ex_alu_op    ),
	.instruction_in  (id_instruction),
	.instruction_out (ex_instruction));

    //------------------------------------------------------------
    // ALU Control
    //------------------------------------------------------------
    alu_control U_ALU_CONTROL (
    .alu_op     (ex_alu_op         ),
    .funct3     (ex_funct3         ),
    .funct7     (ex_funct7         ),
    .alu_ctrl   (ex_alu_ctrl       ));

    //------------------------------------------------------------
    // Forwarding Unit
    //------------------------------------------------------------
    forwarding_unit U_FORWARD (
    // Source Registers
    .id_ex_rs1       (ex_rs1       ),
    .id_ex_rs2       (ex_rs2       ),
    // EX/MEM
    .ex_mem_rd       (mem_rd       ),
    .ex_mem_reg_write(mem_reg_write),
    // MEM/WB
    .mem_wb_rd       (wb_rd        ),
    .mem_wb_reg_write(wb_reg_write ),
    // Outputs
    .forward_a       (forward_a    ),
    .forward_b       (forward_b    ));

    //------------------------------------------------------------
    // Forwarding MUX A
    //------------------------------------------------------------
    always @(*)
      begin
        case(forward_a)
          2'b00:
            alu_operand_a = ex_rs1_data;
          2'b10:
            alu_operand_a = mem_alu_result;
          2'b01:
            alu_operand_a = wb_data;
          default:
            alu_operand_a = ex_rs1_data;
        endcase
      end

    //------------------------------------------------------------
    // Forwarding MUX B (Register Value)
    //------------------------------------------------------------
    always @(*)
      begin
        case(forward_b)
          2'b00:
            alu_operand_b_reg = ex_rs2_data;
          2'b10:
            alu_operand_b_reg = mem_alu_result;
          2'b01:
            alu_operand_b_reg = wb_data;
          default:
            alu_operand_b_reg = ex_rs2_data;
        endcase
      end

    //------------------------------------------------------------
    // ALU Operand B MUX
    //------------------------------------------------------------
    assign alu_operand_b = (ex_alu_src) ? ex_imm : alu_operand_b_reg;

    //------------------------------------------------------------
    // Branch Unit
    //------------------------------------------------------------
    branch_unit U_BRANCH (
    .rs1          (alu_operand_a    ),
    .rs2          (alu_operand_b_reg),
    .funct3       (ex_funct3        ),
    .branch_taken (branch_taken     ));

    //------------------------------------------------------------
    // Branch Target Address
    //------------------------------------------------------------
    assign ex_branch_addr = ex_pc + ex_imm;

    //------------------------------------------------------------
    // ALU
    //------------------------------------------------------------
    alu U_ALU(
    .operand_a    (alu_operand_a   ),
    .operand_b    (alu_operand_b   ),
    .alu_ctrl     (ex_alu_ctrl     ),
    .result       (alu_result      ),
    .zero         (alu_zero        ),
	.overflow     (                ));
    
    //------------------------------------------------------------
    // EX/MEM Pipeline Register
    //------------------------------------------------------------
    ex_mem_reg U_EX_MEM (
    .clk             (clk          ),
    .rst             (rst          ),
    // Flush
    .flush           (1'b0),      // Replace with ex_mem_flush if implemented
    // Data Inputs
    .alu_result_in   (alu_result       ),
    .rs2_data_in     (alu_operand_b_reg),
    .branch_addr_in  (ex_branch_addr   ),
    .zero_in         (branch_taken     ),
    .rd_in           (ex_rd            ),
    // Control Inputs
    .reg_write_in    (ex_reg_write     ),
    .mem_read_in     (ex_mem_read      ),
    .mem_write_in    (ex_mem_write     ),
    .mem_to_reg_in   (ex_mem_to_reg    ),
    .branch_in       (ex_branch        ),
    .jump_in         (ex_jump          ),
    // Outputs
    .alu_result_out  (mem_alu_result   ),
    .rs2_data_out    (mem_write_data   ),
    .branch_addr_out (mem_branch_addr  ),
    .zero_out        (mem_zero         ),
    .rd_out          (mem_rd           ),
    .reg_write_out   (mem_reg_write    ),
    .mem_read_out    (mem_mem_read     ),
    .mem_write_out   (mem_mem_write    ),
    .mem_to_reg_out  (mem_mem_to_reg   ),
    .branch_out      (mem_branch       ),
    .jump_out        (mem_jump         ),
	.instruction_in  (ex_instruction   ),
	.instruction_out (mem_instruction  ));

    //------------------------------------------------------------
    // Branch Redirect (Optional MEM-stage decision)
    //------------------------------------------------------------
    wire [31:0] mem_pc_redirect;
    assign mem_pc_redirect = (mem_branch && mem_zero) || mem_jump;
             
    //------------------------------------------------------------
    // Data Memory
    //------------------------------------------------------------
    data_memory U_DATA_MEMORY(
    .clk            (clk           ),
    // Control
    .mem_read       (mem_mem_read  ),
    .mem_write      (mem_mem_write ),
    // Address
    .address        (mem_alu_result),
    // Store Data
    .write_data     (mem_write_data),
    // Load / Store Type
    .funct3         (mem_funct3    ),
    // Read Data
    .read_data      (mem_read_data ));

    //------------------------------------------------------------
    // MEM/WB Pipeline Register
    //------------------------------------------------------------
    mem_wb_reg U_MEM_WB(
    .clk             (clk            ),
    .rst             (rst            ),
    // Data Inputs
    .alu_result_in   (mem_alu_result ),
    .memory_data_in  (mem_read_data  ),
    .rd_in           (mem_rd         ),
    // Control Inputs
    .reg_write_in    (mem_reg_write  ),
    .mem_to_reg_in   (mem_mem_to_reg ),
    // Outputs
    .alu_result_out  (wb_alu_result  ),
    .memory_data_out (wb_memory_data ),
    .rd_out          (wb_rd          ),
    .reg_write_out   (wb_reg_write   ),
    .mem_to_reg_out  (wb_mem_to_reg  ),
    .pc_in           (mem_pc_redirect),
    .pc_out          (wb_pc          ),
	.instruction_in  (mem_instruction),
	.instruction_out (wb_instruction ));

    //------------------------------------------------------------
    // Write Back MUX
    //------------------------------------------------------------
    assign wb_data = (wb_mem_to_reg) ? wb_memory_data : wb_alu_result;

endmodule             
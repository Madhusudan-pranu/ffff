###############################################################################
# cpu_monitor.py
###############################################################################

import cocotb
from cocotb.triggers import RisingEdge

from cpu_transaction import CPUTransaction


class CPUMonitor:

    def __init__(self, dut):

        self.dut = dut

        self.transactions = []

    ###########################################################################

    def sign_extend(self, value, bits):

        sign = 1 << (bits - 1)
        return (value & (sign - 1)) - (value & sign)

    ###########################################################################

    def decode_instruction(self, txn):

        inst = txn.instruction

        txn.opcode = inst & 0x7F
        txn.rd = (inst >> 7) & 0x1F
        txn.funct3 = (inst >> 12) & 0x7
        txn.rs1 = (inst >> 15) & 0x1F
        txn.rs2 = (inst >> 20) & 0x1F
        txn.funct7 = (inst >> 25) & 0x7F

        #
        # Immediate
        #

        if txn.opcode in [0x13, 0x03]:

            txn.imm = self.sign_extend(
                (inst >> 20) & 0xFFF,
                12
            )

        elif txn.opcode == 0x23:

            imm = ((inst >> 25) << 5) | ((inst >> 7) & 0x1F)

            txn.imm = self.sign_extend(imm, 12)

        elif txn.opcode == 0x63:

            imm = (
                ((inst >> 31) << 12)
                | (((inst >> 7) & 1) << 11)
                | (((inst >> 25) & 0x3F) << 5)
                | (((inst >> 8) & 0xF) << 1)
            )

            txn.imm = self.sign_extend(imm, 13)

    ###########################################################################

    def capture_wb_transaction(self):

        txn = CPUTransaction()

        #
        # IMPORTANT:
        # Replace these signal names with the ones used in your RTL.
        #

        txn.pc = self.dut.mem_wb_pc.value.integer
        txn.instruction = self.dut.mem_wb_instruction.value.integer

        self.decode_instruction(txn)

        #
        # Execute Stage Result
        #

        txn.alu_result = self.dut.ex_mem_alu_result.value.integer

        #
        # Memory Stage
        #

        txn.mem_address = self.dut.ex_mem_alu_result.value.integer

        txn.mem_read = self.dut.mem_mem_read.value.integer

        txn.mem_write = self.dut.mem_mem_write.value.integer

        txn.mem_read_data = self.dut.mem_read_data.value.integer

        txn.mem_write_data = self.dut.mem_write_data.value.integer

        #
        # Write Back
        #

        txn.wb_enable = self.dut.reg_write.value.integer

        txn.wb_rd = self.dut.wb_rd.value.integer

        txn.wb_data = self.dut.wb_data.value.integer

        txn.branch_taken = self.dut.branch_taken.value.integer

        return txn

    ###########################################################################

    async def run(self):

        self.dut._log.info("----------------------------------")
        self.dut._log.info("CPU Pipeline Monitor Started")
        self.dut._log.info("----------------------------------")

        while True:

            await RisingEdge(self.dut.clk)

            txn = self.capture_wb_transaction()

            #
            # Ignore bubbles/NOPs
            #

            if txn.instruction == 0:
                continue

            self.transactions.append(txn)

            self.dut._log.info(
                f"""
----------------------------------------
WB Transaction
----------------------------------------
PC            : 0x{txn.pc:08X}
Instruction   : 0x{txn.instruction:08X}
Opcode        : 0x{txn.opcode:02X}
RS1           : {txn.rs1}
RS2           : {txn.rs2}
RD            : {txn.rd}
Immediate     : 0x{txn.imm & 0xFFFFFFFF:08X}

ALU Result    : 0x{txn.alu_result:08X}

Memory Addr   : 0x{txn.mem_address:08X}
Mem Read      : {txn.mem_read}
Mem Write     : {txn.mem_write}
Mem Read Data : 0x{txn.mem_read_data:08X}
Mem WriteData : 0x{txn.mem_write_data:08X}

WB Enable     : {txn.wb_enable}
WB Register   : x{txn.wb_rd}
WB Data       : 0x{txn.wb_data:08X}

Branch Taken  : {txn.branch_taken}
----------------------------------------
"""
            )
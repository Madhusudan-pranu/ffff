 `ifndef DEFINES_V
`define DEFINES_V

//--------------------------------------------------
// General Parameters
//--------------------------------------------------

`define XLEN            32
`define REG_ADDR_WIDTH   5

//--------------------------------------------------
// Opcodes (RV32I)
//--------------------------------------------------

`define OPCODE_RTYPE    7'b0110011
`define OPCODE_ITYPE    7'b0010011
`define OPCODE_LOAD     7'b0000011
`define OPCODE_STORE    7'b0100011
`define OPCODE_BRANCH   7'b1100011
`define OPCODE_LUI      7'b0110111
`define OPCODE_AUIPC    7'b0010111
`define OPCODE_JAL      7'b1101111
`define OPCODE_JALR     7'b1100111
`define OPCODE_CNTR     7'b0011000


//--------------------------------------------------
// ALU Operations
//--------------------------------------------------

`define ALU_ADD     4'd0
`define ALU_SUB     4'd1
`define ALU_AND     4'd2
`define ALU_OR      4'd3
`define ALU_XOR     4'd4
`define ALU_SLT     4'd5
`define ALU_SLTU    4'd6
`define ALU_SLL     4'd7
`define ALU_SRL     4'd8
`define ALU_SRA     4'd9
`define ALU_COUNTER 4'd10

//--------------------------------------------------
// Memory Size
//--------------------------------------------------

`define IMEM_SIZE 256
`define DMEM_SIZE 256

`endif
###############################################################################
# cpu_monitor.py
###############################################################################

import copy
import os

import cocotb
from cocotb.triggers import RisingEdge, ReadOnly

from cpu_transaction import CPUTransaction


class CPUMonitor:

    def __init__(self, dut):

        self.dut = dut

        # Completed WB transactions
        self.transactions = []

        # Pipeline registers inside monitor
        self.if_txn = None
        self.id_txn = None
        self.ex_txn = None
        self.mem_txn = None
        self.wb_txn = None

        self.cycle = 0
    
        ###########################################################
        # Independent Free Running Counter Reference Model
        ###########################################################
        self.target_opcode = int(os.getenv("CNTR_OPCODE", "0x18"), 0)
        self.reference_count = 0
        self.counter_enable = False
        self.counter_started = False
        
    def get_int_value(self, signal, signal_name=""):
        """
        Safely converts a cocotb signal to integer.
        Returns None if the signal contains X/Z.
        """
        
        value = signal.value
        
        if not value.is_resolvable:
            self.dut._log.warning(
                f"{signal_name} contains X/Z : {value.binstr}"
            )
            return None
        
        return value.integer
        
    ###########################################################################
    # Capture IF Stage
    ###########################################################################

    def capture_if(self):

        txn = CPUTransaction()
        
        txn.instruction = self.get_int_value(
            self.dut.if_instruction,
            "IF Instruction"
        )
        
        txn.pc = self.get_int_value(
            self.dut.pc_current,
            "IF PC"
        )
        
        if txn.instruction is None:
            return None        
        inst = txn.instruction

        txn.opcode = inst & 0x7F
        txn.rd = (inst >> 7) & 0x1F
        txn.funct3 = (inst >> 12) & 0x7
        txn.rs1 = (inst >> 15) & 0x1F
        txn.rs2 = (inst >> 20) & 0x1F
        txn.funct7 = (inst >> 25) & 0x7F

        # I-Type Immediate
        if txn.opcode in [0x13, 0x03]:

            imm = (inst >> 20) & 0xFFF

            if imm & 0x800:
                imm |= 0xFFFFF000

            txn.imm = imm & 0xFFFFFFFF

        # S-Type Immediate
        elif txn.opcode == 0x23:

            imm = ((inst >> 25) << 5) | ((inst >> 7) & 0x1F)

            if imm & 0x800:
                imm |= 0xFFFFF000

            txn.imm = imm & 0xFFFFFFFF

        else:
            txn.imm = 0

        return txn

    ###########################################################################
    # Capture ID Stage
    ###########################################################################

    def update_id(self, txn):

        if txn is None:
            return

        txn.instruction = self.get_int_value(
            self.dut.id_instruction,
            "ID Instruction"
        )
        
        if txn.instruction is None:
            return None
        
    ###########################################################################
    # Capture EX Stage
    ###########################################################################

    def update_ex(self, txn):

        if txn is None:
            return

        try:
            txn.alu_result = self.dut.alu_result.value.integer
        except AttributeError:
            pass

        try:
            txn.branch_taken = self.dut.branch_taken.value.integer
        except AttributeError:
            txn.branch_taken = 0
        
    ###########################################################################
    # Capture MEM Stage
    ###########################################################################

    def update_mem(self, txn):

        if txn is None:
            return

        try:
            txn.mem_read = self.dut.mem_read.value.integer
        except AttributeError:
            txn.mem_read = 0

        try:
            txn.mem_write = self.dut.mem_write.value.integer
        except AttributeError:
            txn.mem_write = 0

        try:
            txn.mem_read_data = self.dut.mem_read_data.value.integer
        except AttributeError:
            txn.mem_read_data = 0

        try:
            txn.mem_write_data = self.dut.mem_write_data.value.integer
        except AttributeError:
            txn.mem_write_data = 0

    ###########################################################################
    # Capture WB Stage
    ###########################################################################

    def update_wb(self, txn):

        if txn is None:
            return

        try:
            txn.wb_enable = self.dut.wb_reg_write.value.integer
        except AttributeError:
            txn.wb_enable = 0

        try:
            txn.wb_rd = self.dut.wb_rd.value.integer
        except AttributeError:
            txn.wb_rd = 0

        try:
            txn.wb_data = self.dut.wb_data.value.integer
        except AttributeError:
            txn.wb_data = 0

    ###########################################################################
    # Counter sampling function
    ###########################################################################
    def get_dut_counter(self):
        # Use existing helper to safely parse integer and log X/Z issues
        val = self.get_int_value(self.dut.count, "DUT Counter Signal")
        return val if val is not None else 0
        
    ###########################################################################
    # Monitor Process
    ###########################################################################

    async def run(self):

        self.dut._log.info("--------------------------------")
        self.dut._log.info("Pipeline Monitor Started")
        self.dut._log.info("--------------------------------")

        while True:

            await RisingEdge(self.dut.clk)

            ###################################################
            # Increment Free Running Counter Reference
            ###################################################
            # Check if target instruction reached EX stage to start counting
            if self.ex_txn is not None and not self.counter_started:
                # Extract opcode (bits [6:0])
                if self.ex_txn.opcode == (self.target_opcode & 0x7F):
                    self.counter_started = True
                    self.counter_enable = True
                    
            # Increment expected counter only after the hardware trigger activates
            if self.counter_enable:
                self.reference_count = (self.reference_count + 1) & 0xFFFFFFFF

            txn = self.capture_if()

            if txn is not None:
                self.if_txn = txn

            ###################################################################
            # Shift pipeline
            ###################################################################

            self.wb_txn = self.mem_txn
            self.mem_txn = self.ex_txn
            self.ex_txn = self.id_txn
            self.id_txn = self.if_txn

            ###################################################################
            # Update stage information
            ###################################################################

            self.update_id(self.id_txn)
            self.update_ex(self.ex_txn)
            self.update_mem(self.mem_txn)
            self.update_wb(self.wb_txn)

            ###################################################################
            # Pipeline display
            ###################################################################

            self.dut._log.info("")
            self.dut._log.info("================ PIPELINE ================")

            if self.if_txn is not None and \
                self.if_txn.pc is not None and \
                self.if_txn.instruction is not None:
                
                self.dut._log.info(
                    f"IF  PC=0x{self.if_txn.pc:08X} "
                    f"INST=0x{self.if_txn.instruction:08X}"
                )

            if self.id_txn is not None and \
                self.id_txn.pc is not None and \
                self.id_txn.instruction is not None:
                
                self.dut._log.info(
                    f"ID  PC=0x{self.id_txn.pc:08X} "
                    f"INST=0x{self.id_txn.instruction:08X}"
                )

            if self.ex_txn is not None and \
                self.ex_txn.pc is not None and \
                self.ex_txn.instruction is not None:
                
                self.dut._log.info(
                    f"EX  PC=0x{self.ex_txn.pc:08X} "
                    f"INST=0x{self.ex_txn.instruction:08X}"
                )

            if self.mem_txn is not None and \
                self.mem_txn.pc is not None and \
                self.mem_txn.instruction is not None:
                
                self.dut._log.info(
                    f"MEM PC=0x{self.mem_txn.pc:08X} "
                    f"INST=0x{self.mem_txn.instruction:08X}"
                )

            if self.wb_txn is not None and \
                self.wb_txn.pc is not None and \
                self.wb_txn.instruction is not None:
                
                self.dut._log.info(
                    f"WB  PC=0x{self.wb_txn.pc:08X} "
                    f"INST=0x{self.wb_txn.instruction:08X}"
                )

            self.dut._log.info("==========================================")

            ###################################################################
            # Retire instruction
            ###################################################################

            if (
                self.wb_txn is not None
                and self.wb_txn.instruction != 0
            ):

                retired = copy.deepcopy(self.wb_txn)

                self.transactions.append(retired)

                self.dut._log.info(
                    "WB Transaction Added : "
                    f"PC=0x{retired.pc:08X} "
                    f"INST=0x{retired.instruction:08X} "
                    f"RD=x{retired.wb_rd} "
                    f"DATA=0x{retired.wb_data:08X}"
                )

            self.cycle += 1            
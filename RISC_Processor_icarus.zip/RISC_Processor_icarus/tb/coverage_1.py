###############################################################################
#
# File Name : cpu_coverage.py
#
# Description:
#
# Functional Coverage Model
# for 5-Stage RISC-V CPU
#
###############################################################################

import cocotb

from cocotb_coverage.coverage import CoverPoint
from cocotb_coverage.coverage import CoverCross
from cocotb_coverage.coverage import coverage_section
from cocotb_coverage.coverage import coverage_db


###############################################################################
# Coverage Model
###############################################################################

CPUCoverage = coverage_section(

    ###########################################################################
    # Opcode Coverage
    ###########################################################################

    CoverPoint(

        "cpu.opcode",

        xf=lambda opcode,
                 rs1,
                 rs2,
                 rd,
                 alu_op,
                 branch,
                 mem_read,
                 mem_write,
                 jump,
                 forward_a,
                 forward_b,
                 stall,
                 flush :

            opcode,

        bins=list(range(128))

    ),

    ###########################################################################
    # RS1 Coverage
    ###########################################################################

    CoverPoint(

        "cpu.rs1",

        xf=lambda opcode,
                 rs1,
                 rs2,
                 rd,
                 alu_op,
                 branch,
                 mem_read,
                 mem_write,
                 jump,
                 forward_a,
                 forward_b,
                 stall,
                 flush :

            rs1,

        bins=list(range(32))

    ),

    ###########################################################################
    # RS2 Coverage
    ###########################################################################

    CoverPoint(

        "cpu.rs2",

        xf=lambda opcode,
                 rs1,
                 rs2,
                 rd,
                 alu_op,
                 branch,
                 mem_read,
                 mem_write,
                 jump,
                 forward_a,
                 forward_b,
                 stall,
                 flush :

            rs2,

        bins=list(range(32))

    ),

    ###########################################################################
    # RD Coverage
    ###########################################################################

    CoverPoint(

        "cpu.rd",

        xf=lambda opcode,
                 rs1,
                 rs2,
                 rd,
                 alu_op,
                 branch,
                 mem_read,
                 mem_write,
                 jump,
                 forward_a,
                 forward_b,
                 stall,
                 flush :

            rd,

        bins=list(range(32))

    ),

    ###########################################################################
    # ALU Operation Coverage
    ###########################################################################

    CoverPoint(

        "cpu.alu_op",

        xf=lambda opcode,
                 rs1,
                 rs2,
                 rd,
                 alu_op,
                 branch,
                 mem_read,
                 mem_write,
                 jump,
                 forward_a,
                 forward_b,
                 stall,
                 flush :

            alu_op,

        bins=[0,1,2,3]

    ),

    ###########################################################################
    # Branch
    ###########################################################################

    CoverPoint(

        "cpu.branch",

        xf=lambda opcode,
                 rs1,
                 rs2,
                 rd,
                 alu_op,
                 branch,
                 mem_read,
                 mem_write,
                 jump,
                 forward_a,
                 forward_b,
                 stall,
                 flush :

            branch,

        bins=[0,1]

    ),

    ###########################################################################
    # Memory Read
    ###########################################################################

    CoverPoint(

        "cpu.mem_read",

        xf=lambda opcode,
                 rs1,
                 rs2,
                 rd,
                 alu_op,
                 branch,
                 mem_read,
                 mem_write,
                 jump,
                 forward_a,
                 forward_b,
                 stall,
                 flush :

            mem_read,

        bins=[0,1]

    ),

    ###########################################################################
    # Memory Write
    ###########################################################################

    CoverPoint(

        "cpu.mem_write",

        xf=lambda opcode,
                 rs1,
                 rs2,
                 rd,
                 alu_op,
                 branch,
                 mem_read,
                 mem_write,
                 jump,
                 forward_a,
                 forward_b,
                 stall,
                 flush :

            mem_write,

        bins=[0,1]

    ),

    ###########################################################################
    # Jump
    ###########################################################################

    CoverPoint(

        "cpu.jump",

        xf=lambda opcode,
                 rs1,
                 rs2,
                 rd,
                 alu_op,
                 branch,
                 mem_read,
                 mem_write,
                 jump,
                 forward_a,
                 forward_b,
                 stall,
                 flush :

            jump,

        bins=[0,1]

    ),

    ###########################################################################
    # Forward A
    ###########################################################################

    CoverPoint(

        "cpu.forward_a",

        xf=lambda opcode,
                 rs1,
                 rs2,
                 rd,
                 alu_op,
                 branch,
                 mem_read,
                 mem_write,
                 jump,
                 forward_a,
                 forward_b,
                 stall,
                 flush :

            forward_a,

        bins=[0,1,2]

    ),

    ###########################################################################
    # Forward B
    ###########################################################################

    CoverPoint(

        "cpu.forward_b",

        xf=lambda opcode,
                 rs1,
                 rs2,
                 rd,
                 alu_op,
                 branch,
                 mem_read,
                 mem_write,
                 jump,
                 forward_a,
                 forward_b,
                 stall,
                 flush :

            forward_b,

        bins=[0,1,2]

    ),

    ###########################################################################
    # Stall
    ###########################################################################

    CoverPoint(

        "cpu.stall",

        xf=lambda opcode,
                 rs1,
                 rs2,
                 rd,
                 alu_op,
                 branch,
                 mem_read,
                 mem_write,
                 jump,
                 forward_a,
                 forward_b,
                 stall,
                 flush :

            stall,

        bins=[0,1]

    ),

    ###########################################################################
    # Flush
    ###########################################################################

    CoverPoint(

        "cpu.flush",

        xf=lambda opcode,
                 rs1,
                 rs2,
                 rd,
                 alu_op,
                 branch,
                 mem_read,
                 mem_write,
                 jump,
                 forward_a,
                 forward_b,
                 stall,
                 flush :

            flush,

        bins=[0,1]

    ),

    ###########################################################################
    # Cross Coverage
    ###########################################################################

    CoverCross(

        "cpu.opcode_x_alu",

        items=[

            "cpu.opcode",

            "cpu.alu_op"

        ]

    )

)


###############################################################################
# Coverage Collector
###############################################################################

class CPUCoverage:

    def __init__(self, dut):

        self.dut = dut

    def sample(self):

        try:

            instruction = int(self.dut.id_instruction.value)

            opcode = instruction & 0x7F

        except:

            opcode = 0

        try:

            rs1 = int(self.dut.rs1_addr.value)

        except:

            rs1 = 0

        try:

            rs2 = int(self.dut.rs2_addr.value)

        except:

            rs2 = 0

        try:

            rd = int(self.dut.ex_rd.value)

        except:

            rd = 0

        try:

            alu_op = int(self.dut.ex_alu_op.value)

        except:

            alu_op = 0

        try:

            branch = int(self.dut.branch_taken.value)

        except:

            branch = 0

        try:

            mem_read = int(self.dut.mem_mem_read.value)

        except:

            mem_read = 0

        try:

            mem_write = int(self.dut.mem_mem_write.value)

        except:

            mem_write = 0

        try:

            jump = int(self.dut.ex_jump.value)

        except:

            jump = 0

        try:

            forward_a = int(self.dut.forward_a.value)

        except:

            forward_a = 0

        try:

            forward_b = int(self.dut.forward_b.value)

        except:

            forward_b = 0

        try:

            stall = int(self.dut.if_id_write.value) == 0

        except:

            stall = 0

        try:

            flush = int(self.dut.id_ex_flush.value)

        except:

            flush = 0

        CPUCoverage(

            opcode,

            rs1,

            rs2,

            rd,

            alu_op,

            branch,

            mem_read,

            mem_write,

            jump,

            forward_a,

            forward_b,

            stall,

            flush

        )

    ###########################################################################

    def report(self):

        print("\n")

        print("==============================================")

        print("CPU Functional Coverage Report")

        print("==============================================")

        coverage_db.report_coverage(print)

        print("==============================================")
`include "defines.v"

module alu_control
(
    input  wire [1:0] alu_op,
    input  wire [2:0] funct3,
    input  wire [6:0] funct7,

    output reg [3:0] alu_ctrl
);

always @(*)
begin

    case(alu_op)

    //--------------------------------------------------
    // LOAD / STORE
    //--------------------------------------------------

    2'b00:
        alu_ctrl = `ALU_ADD;

    //--------------------------------------------------
    // BRANCH
    //--------------------------------------------------

    2'b01:
        alu_ctrl = `ALU_SUB;

    //--------------------------------------------------
    // R-Type
    //--------------------------------------------------

    2'b10:
    begin

        case(funct3)

        //------------------------------------------
        // ADD / SUB
        //------------------------------------------

        3'b000:
        begin
            if(funct7 == 7'b0100000)
                alu_ctrl = `ALU_SUB;
            else
                alu_ctrl = `ALU_ADD;
        end

        //------------------------------------------
        // SLL
        //------------------------------------------

        3'b001:
            alu_ctrl = `ALU_SLL;

        //------------------------------------------
        // SLT
        //------------------------------------------

        3'b010:
            alu_ctrl = `ALU_SLT;

        //------------------------------------------
        // SLTU
        //------------------------------------------

        3'b011:
            alu_ctrl = `ALU_SLTU;

        //------------------------------------------
        // XOR
        //------------------------------------------

        3'b100:
        begin
            if(funct7 == 7'b0100000)
                alu_ctrl = `ALU_COUNTER;
            else
                alu_ctrl = `ALU_XOR;
        end
		

        //------------------------------------------
        // SRL / SRA
        //------------------------------------------

        3'b101:
        begin
            if(funct7 == 7'b0100000)
                alu_ctrl = `ALU_SRA;
            else
                alu_ctrl = `ALU_SRL;
        end

        //------------------------------------------
        // OR
        //------------------------------------------

        3'b110:
            alu_ctrl = `ALU_OR;

        //------------------------------------------
        // AND
        //------------------------------------------

        3'b111:
            alu_ctrl = `ALU_AND;

        default:
            alu_ctrl = `ALU_ADD;

        endcase

    end

    //--------------------------------------------------
    // I-Type Arithmetic
    //--------------------------------------------------

    2'b11:
    begin

        case(funct3)

        3'b000: alu_ctrl = `ALU_ADD;
        3'b010: alu_ctrl = `ALU_SLT;
        3'b011: alu_ctrl = `ALU_SLTU;
        3'b100: alu_ctrl = `ALU_XOR;
        3'b110: alu_ctrl = `ALU_OR;
        3'b111: alu_ctrl = `ALU_AND;
        3'b001: alu_ctrl = `ALU_SLL;

        3'b101:
        begin
            if(funct7 == 7'b0100000)
                alu_ctrl = `ALU_SRA;
            else
                alu_ctrl = `ALU_SRL;
        end

        default:
            alu_ctrl = `ALU_ADD;

        endcase

    end

    default:
        alu_ctrl = `ALU_ADD;

    endcase

end

endmodule
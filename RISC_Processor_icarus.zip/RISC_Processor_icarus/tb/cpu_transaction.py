###############################################################################
# File Name : cpu_transaction.py
#
# Description:
#   Transaction class for RISC-V Processor Verification
#
###############################################################################

class CPUTransaction:

    def __init__(self):

        #######################################################################
        # Instruction Fetch
        #######################################################################

        self.pc = 0
        self.instruction = 0

        #######################################################################
        # Decode Stage
        #######################################################################

        self.opcode = 0
        self.funct3 = 0
        self.funct7 = 0

        self.rs1 = 0
        self.rs2 = 0
        self.rd = 0

        self.imm = 0

        #######################################################################
        # Execute Stage
        #######################################################################

        self.alu_result = 0

        self.branch_taken = 0

        #######################################################################
        # Memory Stage
        #######################################################################

        self.mem_address = 0

        self.mem_read = 0
        self.mem_write = 0

        self.mem_read_data = 0
        self.mem_write_data = 0

        #######################################################################
        # Write Back Stage
        #######################################################################

        self.wb_enable = 0
        self.wb_rd = 0
        self.wb_data = 0

    ###########################################################################
    # Print Transaction
    ###########################################################################

    def __str__(self):

        return (
            "\n"
            "----------------------------------------\n"
            f"PC            : 0x{self.pc:08X}\n"
            f"Instruction   : 0x{self.instruction:08X}\n"
            f"Opcode        : 0x{self.opcode:02X}\n"
            f"RS1           : {self.rs1}\n"
            f"RS2           : {self.rs2}\n"
            f"RD            : {self.rd}\n"
            f"Immediate     : 0x{self.imm:08X}\n"
            f"ALU Result    : 0x{self.alu_result:08X}\n"
            f"Branch Taken  : {self.branch_taken}\n"
            f"Memory Addr   : 0x{self.mem_address:08X}\n"
            f"Mem Read      : {self.mem_read}\n"
            f"Mem Write     : {self.mem_write}\n"
            f"Mem Read Data : 0x{self.mem_read_data:08X}\n"
            f"Mem WriteData : 0x{self.mem_write_data:08X}\n"
            f"WB Enable     : {self.wb_enable}\n"
            f"WB Register   : x{self.wb_rd}\n"
            f"WB Data       : 0x{self.wb_data:08X}\n"
            "----------------------------------------"
        )
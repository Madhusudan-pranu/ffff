###############################################################################
# cpu_reference_model.py
###############################################################################

from cpu_transaction import CPUTransaction


class CPUReferenceModel:

    def __init__(self):

        # Architectural Register File
        self.regfile = [0] * 32

        # Simple Data Memory
        self.memory = {}
        
        self.counter = 0
    ###########################################################################
    # Sign Extension Helper
    ###########################################################################

    def sign_extend(self, value, bits):

        sign = 1 << (bits - 1)

        return (value & (sign - 1)) - (value & sign)

    ###########################################################################
    # Execute ONE retired instruction
    ###########################################################################

    def execute(self, actual_txn):

        instr = actual_txn.instruction

        exp = CPUTransaction()

        ###############################################################
        # Copy PC
        ###############################################################

        exp.pc = actual_txn.pc
        exp.instruction = instr

        ###############################################################
        # Independent Decode
        ###############################################################

        exp.opcode = instr & 0x7F
        exp.rd = (instr >> 7) & 0x1F
        exp.funct3 = (instr >> 12) & 0x7
        exp.rs1 = (instr >> 15) & 0x1F
        exp.rs2 = (instr >> 20) & 0x1F
        exp.funct7 = (instr >> 25) & 0x7F

        ###############################################################
        # Immediate Decode
        ###############################################################

        exp.imm = 0

        # I-Type
        if exp.opcode in [0x13, 0x03]:

            exp.imm = self.sign_extend(
                (instr >> 20) & 0xFFF,
                12
            ) & 0xFFFFFFFF

        # S-Type
        # elif exp.opcode == 0x23:

            # imm = ((instr >> 25) << 5) | ((instr >> 7) & 0x1F)

            # exp.imm = self.sign_extend(
                # imm,
                # 12
            # ) & 0xFFFFFFFF

        ###############################################################
        # Read Register File
        ###############################################################

        rs1 = self.regfile[exp.rs1]
        rs2 = self.regfile[exp.rs2]

        ###############################################################
        # Default Outputs
        ###############################################################

        exp.alu_result = 0

        exp.branch_taken = 0

        exp.mem_read = 0
        exp.mem_write = 0

        exp.mem_address = 0
        exp.mem_read_data = 0
        exp.mem_write_data = 0

        exp.wb_enable = 0
        exp.wb_rd = 0
        exp.wb_data = 0
        exp.count = 0
        ###############################################################
        # R-Type
        ###############################################################

        if exp.opcode == 0x33:

            if exp.funct3 == 0:

                # ADD
                if exp.funct7 == 0x00:

                    exp.alu_result = (rs1 + rs2) & 0xFFFFFFFF

                # SUB
                elif exp.funct7 == 0x20:

                    exp.alu_result = (rs1 - rs2) & 0xFFFFFFFF
                    
            if exp.funct3 == 7:
              # AND
              if exp.funct7 == 0x00:
                  
                  exp.alu_result = (rs1 & rs2)
                  
            if exp.funct3 == 6:
              # OR
              if exp.funct7 == 0x00:
                  
                  exp.alu_result = (rs1 | rs2)
            
            if exp.funct3 == 2:
              # OR
              if exp.funct7 == 0x00:
                  
                  exp.alu_result = 0x00000001 if (rs1 < rs2) else 0x00000000
            
            if exp.funct3 == 3:
              # OR
              if exp.funct7 == 0x00:
                  
                  exp.alu_result = 0x00000001 if (rs1 < rs2) else 0x00000000
                  
            if exp.funct3 == 4:
              # XOR
              if exp.funct7 == 0x20:
                  exp.alu_result = (rs1 + 1) & 0xFFFFFFFF
              else :    
                  exp.alu_result = (rs1 ^ rs2)
                  
               
            if exp.funct3 == 1:
              # Shift Left Logical
              if exp.funct7 == 0x00:
                  
                  exp.alu_result = (rs1 << rs2[4:0])
 
            if exp.funct3 == 5:
              # Shift right Arithematic.
              if exp.funct7 == 0x20:
                signed_rs1 = self.to_signed(rs1, 32)
                exp.alu_result = (signed_rs1 >> shift_amount) & 0xFFFFFFFF
              # Shift right Logical.
              elif exp.funct7 == 0x00:
                exp.alu_result = (rs1 >> rs2[4:0])
                
            exp.wb_enable = 1
            exp.wb_rd = exp.rd
            exp.wb_data = exp.alu_result

        ###############################################################
        # ADDI
        ###############################################################

        elif exp.opcode == 0x13:

          #if exp.funct3 == 0: #ADDI  
            exp.alu_result = (rs1 + exp.imm) & 0xFFFFFFFF
              
            exp.wb_enable = 1
            exp.wb_rd = exp.rd
            exp.wb_data = exp.alu_result

        ###############################################################
        # LW
        ###############################################################

        elif exp.opcode == 0x03:

            addr = (rs1 + exp.imm) & 0xFFFFFFFF

            exp.mem_read = 1
            exp.mem_address = addr

            exp.mem_read_data = self.memory.get(addr, 0)

            exp.wb_enable = 1
            exp.wb_rd = exp.rd
            exp.wb_data = exp.mem_read_data

        ###############################################################
        # LUI and AUIPC
        ###############################################################

        elif exp.opcode == 0x37 or exp.opcode == 0x17:

            operand_b = instr & 0xFFFFF000
            exp.alu_result = (rs1 + operand_b) & 0xFFFFFFFF
            
            exp.mem_write = 1
            exp.mem_address = addr
            exp.mem_write_data = rs2

            self.memory[addr] = rs2

        ###############################################################
        # BEQ
        ###############################################################

        elif exp.opcode == 0x63:

            imm = (
                ((instr >> 31) << 12)
                | (((instr >> 7) & 0x1) << 11)
                | (((instr >> 25) & 0x3F) << 5)
                | (((instr >> 8) & 0xF) << 1)
            )

            exp.imm = self.sign_extend(
                imm,
                13
            ) & 0xFFFFFFFF

            exp.branch_taken = int(rs1 == rs2)

        ###############################################################
        # Register Writeback
        ###############################################################

        if exp.wb_enable and exp.wb_rd != 0:

            self.regfile[exp.wb_rd] = exp.wb_data & 0xFFFFFFFF

        ###############################################################
        # x0 Always Zero
        ###############################################################

        self.regfile[0] = 0

        ###############################################################
        # Debug
        ###############################################################

        # print("\n[REFERENCE MODEL]")
        # print(f"PC          : 0x{exp.pc:08X}")
        # print(f"Instruction : 0x{exp.instruction:08X}")
        # print(f"Opcode      : 0x{exp.opcode:02X}")
        # print(f"RS1         : x{exp.rs1} = 0x{rs1:08X}")
        # print(f"RS2         : x{exp.rs2} = 0x{rs2:08X}")
        # print(f"RD          : x{exp.rd}")
        # print(f"IMM         : 0x{exp.imm:08X}")
        # print(f"ALU Result  : 0x{exp.alu_result:08X}")
        # print(f"WB Enable   : {exp.wb_enable}")
        # print(f"WB RD       : x{exp.wb_rd}")
        # print(f"WB DATA     : 0x{exp.wb_data:08X}")

        return exp
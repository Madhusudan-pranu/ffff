`timescale 1ns / 1ps
`include "defines.v"

module cpu_top
(
    input  wire clk,
    input  wire rst
);

    //------------------------------------------------------------
    // Program Counter Signals
    //------------------------------------------------------------
    wire [31:0] pc_current;
    wire [31:0] pc_next;
    wire [31:0] pc_plus4;

    //------------------------------------------------------------
    // Instruction Fetch
    //------------------------------------------------------------
    wire [31:0] instruction_if;
    wire        if_id_stall;
    wire        if_id_flush;
    //------------------------------------------------------------
    // IF/ID Pipeline Signals
    //------------------------------------------------------------
    wire [31:0] if_id_pc;
    wire [31:0] if_id_instruction;

    //------------------------------------------------------------
    // Decode Stage
    //------------------------------------------------------------

    // Instruction Fields
    wire [6:0] opcode;
    wire [4:0] rd;
    wire [2:0] funct3;
    wire [4:0] rs1;
    wire [4:0] rs2;
    wire [6:0] funct7;

    // Register File
    wire [31:0] rs1_data;
    wire [31:0] rs2_data;

    // Immediate
    wire [31:0] immediate;

    // Control Signals
    wire reg_write;
    wire mem_read;
    wire mem_write;
    wire mem_to_reg;
    wire alu_src;
    wire branch;
    wire jump;
    wire [1:0] alu_op;

    //------------------------------------------------------------
    // ID/EX Pipeline Signals
    //------------------------------------------------------------

    wire [31:0] id_ex_pc;
    wire [31:0] id_ex_rs1_data;
    wire [31:0] id_ex_rs2_data;
    wire [31:0] id_ex_imm;

    wire [4:0] id_ex_rs1;
    wire [4:0] id_ex_rs2;
    wire [4:0] id_ex_rd;

    wire [2:0] id_ex_funct3;
    wire [6:0] id_ex_funct7;

    wire id_ex_reg_write;
    wire id_ex_mem_read;
    wire id_ex_mem_write;
    wire id_ex_mem_to_reg;
    wire id_ex_alu_src;
    wire id_ex_branch;
    wire id_ex_jump;
    wire [1:0] id_ex_alu_op;

    //------------------------------------------------------------
    // Execute Stage
    //------------------------------------------------------------

    wire [3:0] alu_ctrl;

    wire [1:0] forward_a;
    wire [1:0] forward_b;

    reg [31:0] alu_operand_a;
    wire [31:0] alu_operand_b;
    reg [31:0] alu_operand_b_reg;

    wire [31:0] alu_result;
    wire alu_zero;
    wire alu_overflow;

    wire branch_taken;

    wire [31:0] branch_target;
    wire [31:0] branch_rs1;
    wire [31:0] branch_rs2;
    //------------------------------------------------------------
    // EX/MEM Pipeline
    //------------------------------------------------------------

    wire [31:0] ex_mem_alu_result;
    wire [31:0] ex_mem_rs2_data;
    wire [31:0] ex_mem_branch_addr;

    wire ex_mem_zero;

    wire [4:0] ex_mem_rd;

    wire ex_mem_reg_write;
    wire ex_mem_mem_read;
    wire ex_mem_mem_write;
    wire ex_mem_mem_to_reg;
    wire ex_mem_branch;
    wire ex_mem_jump;
    //------------------------------------------------------------
    // Memory Stage
    //------------------------------------------------------------

    //wire [31:0] memory_read_data;

    //------------------------------------------------------------
    // MEM/WB Pipeline
    //------------------------------------------------------------

    wire [31:0] mem_wb_alu_result;
    wire [31:0] mem_wb_memory_data;

    wire [4:0] mem_wb_rd;

    wire mem_wb_reg_write;
    wire mem_wb_mem_to_reg;
    //--------------------------------------------------
    // Memory Stage
    //--------------------------------------------------
    
    wire [31:0] mem_alu_result;
    wire [31:0] mem_write_data;
    wire [31:0] mem_read_data;
    wire [31:0] mem_branch_addr;
    wire        mem_zero;
    wire [4:0]  mem_rd;
    wire        mem_reg_write;
    wire        mem_mem_read;
    wire        mem_mem_write;
    wire        mem_mem_to_reg;
    wire        mem_branch;
    wire        mem_jump;
    //------------------------------------------------------------
    // Write Back
    //------------------------------------------------------------

    wire [31:0] wb_data;

    //------------------------------------------------------------
    // Hazard Detection
    //------------------------------------------------------------

    wire pc_write;
    wire if_id_write;
    wire id_ex_flush;

    //------------------------------------------------------------
    // Program Counter
    //------------------------------------------------------------

    pc PC_INST (
    .clk            ( clk       ),
    .rst            ( rst       ),
    .pc_write       ( pc_write  ),
    .next_pc        ( pc_next   ),
    .pc             ( pc_current));
    //------------------------------------------------------------
    // PC + 4 Logic
    //------------------------------------------------------------

    assign pc_plus4 = pc_current + 32'd4;

    //------------------------------------------------------------
    // Next PC MUX
    //------------------------------------------------------------

    // TODO:
    assign pc_next =
    ((id_ex_branch && branch_taken) || id_ex_jump) ? branch_target : pc_plus4;

    //------------------------------------------------------------
    // Instruction Memory
    //------------------------------------------------------------

    // TODO:
    // instruction_memory IMEM (...)
    instruction_memory IMEM (
    .address       ( pc_current     ),
    .instruction   ( instruction_if ));
	
    //------------------------------------------------------------
    // IF/ID Register
    //------------------------------------------------------------

    // TODO:
    // if_id_reg IF_ID (...)
    if_id_reg U_IF_ID (
    .clk             (clk              ),
    .rst             (rst              ),
    .stall           (if_id_stall      ),
    .flush           (if_id_flush      ),
    .pc_in           (pc_current       ),
    .instruction_in  (instruction_if   ),
    .pc_out          (if_id_pc         ),
    .instruction_out (if_id_instruction));
	
    //------------------------------------------------------------
    // Instruction Decode
    //------------------------------------------------------------

    assign opcode = if_id_instruction[6:0];
    assign rd     = if_id_instruction[11:7];
    assign funct3 = if_id_instruction[14:12];
    assign rs1    = if_id_instruction[19:15];
    assign rs2    = if_id_instruction[24:20];
    assign funct7 = if_id_instruction[31:25];
    assign ex_mem_branch_addr = id_ex_pc + id_ex_imm;
    //------------------------------------------------------------
    // Register File
    //------------------------------------------------------------

    // TODO:
    // register_file RF (...)
    register_file RF(
    .clk      ( clk       ),
    .rst      ( rst       ),
    // Read Port 1        
    .rs1_addr ( rs1       ),
    .rs1_data ( rs1_data  ),
    // Read Port 2
    .rs2_addr ( rs2       ),
    .rs2_data ( rs2_data  ),
    // Write Port
    .reg_write( mem_wb_reg_write ),
    .rd_addr  ( mem_wb_rd ),
    .rd_data  ( wb_data   ));
    //------------------------------------------------------------
    // Immediate Generator
    //------------------------------------------------------------

    // TODO:
    // immediate_generator IMM (...)
    immediate_generator IMM (
    .instruction ( if_id_instruction),
    .immediate   ( immediate));
    //------------------------------------------------------------
    // Control Unit
    //------------------------------------------------------------

    // TODO:
    // control_unit CTRL (...)
    control_unit U_CONTROL(
    .opcode      (opcode      ),
    .reg_write   (reg_write   ),
    .mem_read    (mem_read    ),
    .mem_write   (mem_write   ),
    .mem_to_reg  (mem_to_reg  ),
    .alu_src     (alu_src     ),
    .branch      (branch      ),
    .jump        (jump        ),
    .alu_op      (alu_op      ));
    //------------------------------------------------------------
    // Hazard Detection Unit
    //------------------------------------------------------------
    assign if_id_stall = ~if_id_write;
    assign if_id_flush = 1'b0;      // or branch flush
    // TODO:
    // hazard_detection_unit HAZARD (...)
    hazard_detection_unit U_HAZARD(
    .id_ex_mem_read (id_ex_mem_read),
    .id_ex_rd       (id_ex_rd),
    .if_id_rs1      (rs1),
    .if_id_rs2      (rs2),
    .pc_write       (pc_write),
    .if_id_write    (if_id_write),
    .id_ex_flush    (id_ex_flush)
);
    //------------------------------------------------------------
    // ID/EX Register
    //------------------------------------------------------------

    // TODO:
    // id_ex_reg ID_EX (...)
    id_ex_reg U_ID_EX(
    .clk             (clk),
    .rst             (rst),
    .flush           (id_ex_flush),
    //-------------------------------------------------
    // Data
    //-------------------------------------------------
    .pc_in           (pc_current),
    .rs1_data_in     (rs1_data  ),
    .rs2_data_in     (rs2_data  ),
    .imm_in          (immediate ),
    .rs1_in          (rs1       ),
    .rs2_in          (rs2       ),
    .rd_in           (rd        ),
    .funct3_in       (funct3    ),
    .funct7_in       (funct7    ),
    //-------------------------------------------------
    // Control
    //-------------------------------------------------
    .reg_write_in    (reg_write ),
    .mem_read_in     (mem_read  ),
    .mem_write_in    (mem_write ),
    .mem_to_reg_in   (mem_to_reg),
    .alu_src_in      (alu_src   ),
    .branch_in       (branch    ),
    .jump_in         (jump      ),
    .alu_op_in       (alu_op    ),
    //-------------------------------------------------
    // Outputs
    //-------------------------------------------------
    .pc_out          (id_ex_pc        ),
    .rs1_data_out    (id_ex_rs1_data  ),
    .rs2_data_out    (id_ex_rs2_data  ),
    .imm_out         (id_ex_imm       ),
    .rs1_out         (id_ex_rs1       ),
    .rs2_out         (id_ex_rs2       ),
    .rd_out          (id_ex_rd        ),
    .funct3_out      (id_ex_funct3    ),
    .funct7_out      (id_ex_funct7    ),
    .reg_write_out   (id_ex_reg_write ),
    .mem_read_out    (id_ex_mem_read  ),
    .mem_write_out   (id_ex_mem_write ),
    .mem_to_reg_out  (id_ex_mem_to_reg),
    .alu_src_out     (id_ex_alu_src   ),
    .branch_out      (id_ex_branch    ),
    .jump_out        (id_ex_jump      ),
    .alu_op_out      (id_ex_alu_op    )
);
    //------------------------------------------------------------
    // ALU Control
    //------------------------------------------------------------

    // TODO:
    // alu_control ALUCTRL (...)
    alu_control U_ALU_CONTROL(
    .alu_op   (id_ex_alu_op),
    .funct3   (id_ex_funct3),
    .funct7   (id_ex_funct7),
    .alu_ctrl (alu_ctrl    ));
    //------------------------------------------------------------
    // Forwarding Unit
    //------------------------------------------------------------

    // TODO:
    // forwarding_unit FWD (...)
    forwarding_unit U_FORWARD(
    //--------------------------------------------------
    // ID/EX
    //--------------------------------------------------
    .id_ex_rs1        (id_ex_rs1),
    .id_ex_rs2        (id_ex_rs2),
    //--------------------------------------------------
    // EX/MEM
    //--------------------------------------------------
    .ex_mem_rd        (id_ex_mem_read),
    .ex_mem_reg_write (id_ex_reg_write),
    //--------------------------------------------------
    // MEM/WB
    //--------------------------------------------------
    .mem_wb_rd        (mem_wb_rd),
    .mem_wb_reg_write (mem_wb_reg_write),
    //--------------------------------------------------
    // Outputs
    //--------------------------------------------------
    .forward_a        (forward_a),
    .forward_b        (forward_b));
    //------------------------------------------------------------
    // ALU Operand MUXes
    //------------------------------------------------------------

    // TODO:
    // Forwarding MUX A
    always @(*) begin
      case (forward_a)
        2'b00: alu_operand_a = id_ex_rs1_data;        // No forwarding
        2'b10: alu_operand_a = ex_mem_alu_result;  // From EX/MEM
        2'b01: alu_operand_a = wb_data;            // From MEM/WB
        default: alu_operand_a = id_ex_rs1_data;
      endcase
    end
    // TODO:
    // Forwarding MUX B
    always @(*) begin
      case (forward_b)
        2'b00: alu_operand_b_reg = id_ex_rs2_data;        // No forwarding
        2'b10: alu_operand_b_reg = ex_mem_alu_result;  // From EX/MEM
        2'b01: alu_operand_b_reg = wb_data;            // From MEM/WB
        default: alu_operand_b_reg = id_ex_rs2_data;
      endcase
    end
    //------------------------------------------------------------
    // ALUSrc MUX
    //------------------------------------------------------------

    // TODO:
    // Select Immediate/Register
    assign alu_operand_b = (ex_alu_src) ? ex_imm : alu_operand_b_reg;
    //------------------------------------------------------------
    // ALU
    //------------------------------------------------------------

    // TODO:
    // alu ALU (...)
    alu U_ALU (
    .operand_a (alu_operand_a),
    .operand_b (alu_operand_b),
    .alu_ctrl  (alu_ctrl     ),
    .result    (alu_result   ),
    .zero      (alu_zero     ),
	.overflow  (alu_overflow ));
    //------------------------------------------------------------
    // Branch Unit
    //------------------------------------------------------------
    assign branch_rs1 = alu_operand_a;
    assign branch_rs2 = alu_operand_b_reg;
    // TODO:
    // branch_unit BR (...)
    branch_unit U_BRANCH (
    .rs1          (branch_rs1  ),
    .rs2          (branch_rs2  ),
    .funct3       (id_ex_funct3),
    .branch_taken (branch_taken));
    //------------------------------------------------------------
    // Branch Target
    //------------------------------------------------------------

    assign branch_target = id_ex_pc + id_ex_imm;

    //------------------------------------------------------------
    // EX/MEM Register
    //------------------------------------------------------------

    // TODO:
    // ex_mem_reg EX_MEM (...)
    ex_mem_reg U_EX_MEM (
    .clk              (clk                ),
    .rst              (rst                ),
    .flush            (1'b0               ),          // or ex_mem_flush
    //--------------------------------------------------
    // Data Inputs
    //--------------------------------------------------
    .alu_result_in    (alu_result         ),
    .rs2_data_in      (alu_operand_b_reg  ),
    .branch_addr_in   (ex_mem_branch_addr ),
    .zero_in          (branch_taken       ),
    .rd_in            (ex_mem_rd          ),
    //--------------------------------------------------
    // Control Inputs
    //--------------------------------------------------
    .reg_write_in     (ex_mem_reg_write   ),
    .mem_read_in      (ex_mem_mem_read    ),
    .mem_write_in     (ex_mem_mem_write   ),
    .mem_to_reg_in    (ex_mem_mem_to_reg  ),
    .branch_in        (ex_mem_branch      ),
    .jump_in          (ex_mem_jump        ),
    //--------------------------------------------------
    // Outputs
    //--------------------------------------------------
    .alu_result_out   (mem_alu_result     ),
    .rs2_data_out     (mem_write_data     ),
    .branch_addr_out  (mem_branch_addr    ),
    .zero_out         (mem_zero           ),
    .rd_out           (mem_rd             ),
    .reg_write_out    (mem_reg_write      ),
    .mem_read_out     (mem_mem_read       ),
    .mem_write_out    (mem_mem_write      ),
    .mem_to_reg_out   (mem_mem_to_reg     ),
    .branch_out       (mem_branch         ),
    .jump_out         (mem_jump           ));
    //------------------------------------------------------------
    // Data Memory
    //------------------------------------------------------------

    // TODO:
    // data_memory DMEM (...)
    data_memory U_DATA_MEMORY (
    .clk        (clk),
    //-------------------------------------------------
    // Control
    //-------------------------------------------------
    .mem_read   (mem_mem_read),
    .mem_write  (mem_mem_write),
    //-------------------------------------------------
    // Address
    //-------------------------------------------------
    .address    (mem_alu_result),
    //-------------------------------------------------
    // Store Data
    //-------------------------------------------------
    .write_data (mem_write_data),
    //-------------------------------------------------
    // Load/Store Type
    //-------------------------------------------------
    .funct3     (id_ex_funct3),
    //-------------------------------------------------
    // Read Data
    //-------------------------------------------------
    .read_data  (mem_read_data));
    //------------------------------------------------------------
    // MEM/WB Register
    //------------------------------------------------------------

    // TODO:
    // mem_wb_reg MEM_WB (...)
    //------------------------------------------------------
// MEM/WB Pipeline Register
//------------------------------------------------------

    mem_wb_reg U_MEM_WB (
    .clk             (clk),
    .rst             (rst),
    //--------------------------------------------------
    // Data Inputs
    //--------------------------------------------------
    .alu_result_in   (mem_alu_result),
    .memory_data_in  (mem_read_data),
    .rd_in           (mem_rd),
    //--------------------------------------------------
    // Control Inputs
    //--------------------------------------------------
    .reg_write_in    (mem_reg_write),
    .mem_to_reg_in   (mem_mem_to_reg),
    //--------------------------------------------------
    // Outputs
    //--------------------------------------------------
    .alu_result_out  (mem_wb_alu_result),
    .memory_data_out (mem_wb_memory_data),
    .rd_out          (mem_wb_rd),
    .reg_write_out   (mem_wb_reg_write),
    .mem_to_reg_out  (mem_wb_mem_to_reg));
    //------------------------------------------------------------
    // Write Back MUX
    //------------------------------------------------------------

    assign wb_data =
        (mem_wb_mem_to_reg) ? mem_wb_memory_data : mem_wb_alu_result;

endmodule
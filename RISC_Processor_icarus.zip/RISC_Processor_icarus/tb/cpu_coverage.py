from cocotb_coverage.coverage import coverage_section
from cocotb_coverage.coverage import CoverPoint

CPUCoverage = coverage_section(

    # Instruction opcode coverage
    CoverPoint(
        "cpu.opcode",
        xf=lambda opcode, alu_op, branch, mem_read, mem_write: opcode,
        bins=[
            0x33,   # R-Type
            0x13,   # I-Type
            0x03,   # Load
            0x23,   # Store
            0x63,   # Branch
            0x37,   # LUI
            0x17,   # AUIPC
            0x6F,   # JAL
            0x67    # JALR
        ]
    ),

    # ALU operation coverage
    CoverPoint(
        "cpu.alu_op",
        xf=lambda opcode, alu_op, branch, mem_read, mem_write: alu_op,
        bins=list(range(16))
    ),

    # Branch taken / not taken
    CoverPoint(
        "cpu.branch",
        xf=lambda opcode, alu_op, branch, mem_read, mem_write: branch,
        bins=[0, 1]
    ),

    # Memory read
    CoverPoint(
        "cpu.mem_read",
        xf=lambda opcode, alu_op, branch, mem_read, mem_write: mem_read,
        bins=[0, 1]
    ),

    # Memory write
    CoverPoint(
        "cpu.mem_write",
        xf=lambda opcode, alu_op, branch, mem_read, mem_write: mem_write,
        bins=[0, 1]
    )
)

@CPUCoverage
def sample_coverage(opcode,
                    alu_op,
                    branch,
                    mem_read,
                    mem_write):
    pass
###############################################################################
# cpu_scoreboard.py
###############################################################################

from cpu_reference_model import CPUReferenceModel


class CPUScoreboard:

    def __init__(self, dut):
        self.dut = dut
        self.total = 0
        self.pass_count = 0
        self.fail_count = 0
        self.errors = 0

    def compare(self, expected_txn, actual_txn):
        """
        Executes real-time transaction comparison at instruction completion time (WB phase).
        """
        self.total += 1
        errors = []

        self.dut._log.info("")
        self.dut._log.info(
            f"========== SCOREBOARD [PC: 0x{actual_txn.pc:08X}] =========="
        )
        self.dut._log.info(f"Expected : DATA=0x{expected_txn.wb_data:08X}")
        self.dut._log.info(f"Actual   : DATA=0x{actual_txn.wb_data:08X}")

        #######################################################################
        # Perform Field Checks
        #######################################################################
        if expected_txn.pc != actual_txn.pc:
            errors.append(
                f"PC Mismatch -> Expected=0x{expected_txn.pc:08X}, Actual=0x{actual_txn.pc:08X}"
            )

        if expected_txn.instruction != actual_txn.instruction:
            errors.append(
                f"Instruction Mismatch -> Expected=0x{expected_txn.instruction:08X}, Actual=0x{actual_txn.instruction:08X}"
            )

        if expected_txn.wb_data != actual_txn.wb_data:
            errors.append(
                f"WB_DATA Mismatch -> Expected=0x{expected_txn.wb_data:08X}, Actual=0x{actual_txn.wb_data:08X}"
            )

        if getattr(expected_txn, 'mem_read', False):
            if expected_txn.mem_read_data != actual_txn.mem_read_data:
                errors.append(
                    f"MEM_READ_DATA Mismatch -> Expected=0x{expected_txn.mem_read_data:08X}, Actual=0x{actual_txn.mem_read_data:08X}"
                )

        if getattr(expected_txn, 'mem_write', False):
            if expected_txn.mem_write_data != actual_txn.mem_write_data:
                errors.append(
                    f"MEM_WRITE_DATA Mismatch -> Expected=0x{expected_txn.mem_write_data:08X}, Actual=0x{actual_txn.mem_write_data:08X}"
                )

        #######################################################################
        # Result Reporting
        #######################################################################
        if len(errors) == 0:
            self.pass_count += 1
            self.dut._log.info("RESULT : PASS")
        else:
            self.fail_count += 1
            self.errors += len(errors)
            self.dut._log.error("RESULT : FAIL")
            for err in errors:
                self.dut._log.error(f"  [ERROR] {err}")

        self.dut._log.info("=======================================")
        self.dut._log.info("")

    def compare_counter(self, expected_count, actual_count):
        """
        Executes free-running counter check per clock cycle.
        """
        self.dut._log.info("")
        self.dut._log.info("========== COUNTER SCOREBOARD ==========")
        self.dut._log.info(f"Expected : {expected_count}")
        self.dut._log.info(f"Actual   : {actual_count}")

        if expected_count == actual_count:
            self.dut._log.info("RESULT   : PASS")
        else:
            self.fail_count += 1
            self.errors += 1
            self.dut._log.error(
                f"RESULT   : FAIL (Expected={expected_count}, Actual={actual_count})"
            )
        self.dut._log.info("========================================")

    def report(self):
        """
        Final summary report called at the end of simulation.
        """
        self.dut._log.info("")
        self.dut._log.info("========================================")
        self.dut._log.info("          SCOREBOARD SUMMARY")
        self.dut._log.info("========================================")
        self.dut._log.info(f"Total Transactions : {self.total}")
        self.dut._log.info(f"Passed             : {self.pass_count}")
        self.dut._log.info(f"Failed             : {self.fail_count}")
        self.dut._log.info("========================================")

        if self.fail_count == 0:
            self.dut._log.info("TEST PASSED")
        else:
            self.dut._log.error("TEST FAILED")           
###############################################################################
# cpu_scoreboard.py
###############################################################################

from cpu_reference_model import CPUReferenceModel


class CPUScoreboard:

    def __init__(self, dut):

        self.dut = dut

        self.total = 0
        self.pass_count = 0
        self.fail_count = 0
        self.errors = 0


    def compare(self, expected_txn, actual_txn):

        self.total += 1

        self.dut._log.info("")
        self.dut._log.info("========== SCOREBOARD ==========")

        self.dut._log.info(
            f"Expected : DATA=0x{expected_txn.wb_data:08X}"
        )

        self.dut._log.info(
            f"Actual   : DATA=0x{actual_txn.wb_data:08X}"
        )

        if (
            expected_txn.wb_data == actual_txn.wb_data
        ):

            self.pass_count += 1
            self.dut._log.info("RESULT : PASS")

        else:

            self.fail_count += 1
            self.dut._log.error("RESULT : FAIL")

        if expected_txn.pc != actual_txn.pc:
            self.errors += 1
            self.dut._log.error("PC Mismatch")
            return
        
        # if expected_txn.rd != actual_txn.rd:
            # self.errors += 1
            # self.dut._log.error("RD Mismatch")
            # return
        
        if expected_txn.wb_data != actual_txn.wb_data:
            self.errors += 1
            self.dut._log.error("WB Data Mismatch")
            return
        
        self.dut._log.info("PASS")
        self.dut._log.info("===============================")
        self.dut._log.info("")

        #######################################################################
        # Compare PC
        #######################################################################

        if expected_txn.pc != actual_txn.pc:

            errors.append(
                f"PC Expected=0x{expected_txn.pc:08X} "
                f"Actual=0x{actual_txn.pc:08X}"
            )

        #######################################################################
        # Compare Instruction
        #######################################################################

        if expected_txn.instruction != actual_txn.instruction:

            errors.append(
                f"Instruction Expected=0x{expected_txn.instruction:08X} "
                f"Actual=0x{actual_txn.instruction:08X}"
            )

        #######################################################################
        # Compare ALU Result
        #######################################################################

        if expected_txn.alu_result != actual_txn.alu_result:

            errors.append(
                f"ALU Expected=0x{expected_txn.alu_result:08X} "
                f"Actual=0x{actual_txn.alu_result:08X}"
            )

        #######################################################################
        # Compare Register Write
        #######################################################################

        if expected_txn.wb_enable != actual_txn.wb_enable:

            errors.append(
                f"WB Enable Expected={expected_txn.wb_enable} "
                f"Actual={actual_txn.wb_enable}"
            )

        #######################################################################
        # Compare Destination Register
        #######################################################################

        if expected_txn.wb_rd != actual_txn.wb_rd:

            errors.append(
                f"WB_RD Expected=x{expected_txn.wb_rd} "
                f"Actual=x{actual_txn.wb_rd}"
            )

        #######################################################################
        # Compare WB Data
        #######################################################################

        if expected_txn.wb_data != actual_txn.wb_data:

            errors.append(
                f"WB_DATA Expected=0x{expected_txn.wb_data:08X} "
                f"Actual=0x{actual_txn.wb_data:08X}"
            )

        #######################################################################
        # Compare Memory Read Data
        #######################################################################

        if expected_txn.mem_read:

            if expected_txn.mem_read_data != actual_txn.mem_read_data:

                errors.append(
                    f"MEM_READ_DATA "
                    f"Expected=0x{expected_txn.mem_read_data:08X} "
                    f"Actual=0x{actual_txn.mem_read_data:08X}"
                )

        #######################################################################
        # Compare Memory Write Data
        #######################################################################

        if expected_txn.mem_write:

            if expected_txn.mem_write_data != actual_txn.mem_write_data:

                errors.append(
                    f"MEM_WRITE_DATA "
                    f"Expected=0x{expected_txn.mem_write_data:08X} "
                    f"Actual=0x{actual_txn.mem_write_data:08X}"
                )

    ###########################################################################
    # Summary
    ###########################################################################

    def report(self):

        self.dut._log.info("")
        self.dut._log.info("========================================")
        self.dut._log.info("          SCOREBOARD SUMMARY")
        self.dut._log.info("========================================")
        self.dut._log.info(f"Total Transactions : {self.total}")
        self.dut._log.info(f"Passed             : {self.pass_count}")
        self.dut._log.info(f"Failed             : {self.fail_count}")
        self.dut._log.info("========================================")

        if self.fail_count == 0:

            self.dut._log.info("TEST PASSED")

        else:

            self.dut._log.error("TEST FAILED")            
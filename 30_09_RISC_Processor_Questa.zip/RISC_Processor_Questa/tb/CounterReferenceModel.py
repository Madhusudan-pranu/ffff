class CounterReferenceModel:

    def __init__(self, counter_opcode=0x18):

        self.counter_opcode = counter_opcode
        self.count = 0

    def reset(self):

        self.count = 0

    def process_opcode(self, opcode):

        if opcode == self.counter_opcode:
            self.count = (self.count + 1) & 0xFFFFFFFF

        return self.count

    def get_count(self):

        return self.count
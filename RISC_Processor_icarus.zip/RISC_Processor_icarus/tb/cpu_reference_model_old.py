###############################################################################
# File Name : cpu_reference_model.py
###############################################################################

from cpu_transaction import CPUTransaction


class CPUReferenceModel:

    ###########################################################################
    # Constructor
    ###########################################################################

    def __init__(self):

        # Architectural Register File
        self.reg = [0] * 32

        # Program Counter
        self.pc = 0

        # Data Memory
        self.memory = {}

    ###########################################################################
    # Sign Extension
    ###########################################################################

    def sign_extend(self, value, bits):

        sign = 1 << (bits - 1)

        return (value & (sign - 1)) - (value & sign)

    ###########################################################################
    # Execute Instruction
    ###########################################################################

    def execute(self, instruction):

        txn = CPUTransaction()

        txn.pc = self.pc
        txn.instruction = instruction

        opcode = instruction & 0x7F

        rd = (instruction >> 7) & 0x1F
        funct3 = (instruction >> 12) & 0x07
        rs1 = (instruction >> 15) & 0x1F
        rs2 = (instruction >> 20) & 0x1F
        funct7 = (instruction >> 25) & 0x7F

        txn.opcode = opcode
        txn.rd = rd
        txn.rs1 = rs1
        txn.rs2 = rs2
        txn.funct3 = funct3
        txn.funct7 = funct7

        #######################################################################
        # R-Type
        #######################################################################

        if opcode == 0x33:

            if funct3 == 0 and funct7 == 0x00:

                result = self.reg[rs1] + self.reg[rs2]

            elif funct3 == 0 and funct7 == 0x20:

                result = self.reg[rs1] - self.reg[rs2]

            elif funct3 == 7:

                result = self.reg[rs1] & self.reg[rs2]

            elif funct3 == 6:

                result = self.reg[rs1] | self.reg[rs2]

            elif funct3 == 4:

                result = self.reg[rs1] ^ self.reg[rs2]

            else:

                result = 0

            result &= 0xFFFFFFFF

            self.reg[rd] = result

            txn.alu_result = result
            txn.wb_enable = 1
            txn.wb_rd = rd
            txn.wb_data = result

            self.pc += 4

        #######################################################################
        # ADDI
        #######################################################################

        elif opcode == 0x13:

            imm = self.sign_extend(instruction >> 20, 12)

            txn.imm = imm

            result = (self.reg[rs1] + imm) & 0xFFFFFFFF

            self.reg[rd] = result

            txn.alu_result = result
            txn.wb_enable = 1
            txn.wb_rd = rd
            txn.wb_data = result

            self.pc += 4

        #######################################################################
        # LW
        #######################################################################

        elif opcode == 0x03:

            imm = self.sign_extend(instruction >> 20, 12)

            address = self.reg[rs1] + imm

            data = self.memory.get(address, 0)

            self.reg[rd] = data

            txn.mem_address = address
            txn.mem_read = 1
            txn.mem_read_data = data

            txn.wb_enable = 1
            txn.wb_rd = rd
            txn.wb_data = data

            self.pc += 4

        #######################################################################
        # SW
        #######################################################################

        elif opcode == 0x23:

            imm = ((instruction >> 25) << 5) | ((instruction >> 7) & 0x1F)

            imm = self.sign_extend(imm, 12)

            address = self.reg[rs1] + imm

            self.memory[address] = self.reg[rs2]

            txn.mem_address = address
            txn.mem_write = 1
            txn.mem_write_data = self.reg[rs2]

            self.pc += 4

        #######################################################################
        # BEQ
        #######################################################################

        elif opcode == 0x63:

            imm = (
                ((instruction >> 31) << 12)
                | (((instruction >> 7) & 1) << 11)
                | (((instruction >> 25) & 0x3F) << 5)
                | (((instruction >> 8) & 0xF) << 1)
            )

            imm = self.sign_extend(imm, 13)

            if self.reg[rs1] == self.reg[rs2]:

                txn.branch_taken = 1

                self.pc += imm

            else:

                txn.branch_taken = 0

                self.pc += 4

        #######################################################################
        # Keep x0 Constant
        #######################################################################

        self.reg[0] = 0

        txn.pc = self.pc

        return txn
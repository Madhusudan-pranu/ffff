module forwarding_unit
(
    //--------------------------------------------------
    // Source Registers from ID/EX
    //--------------------------------------------------
    input  wire [4:0] id_ex_rs1,
    input  wire [4:0] id_ex_rs2,

    //--------------------------------------------------
    // Destination Register from EX/MEM
    //--------------------------------------------------
    input  wire [4:0] ex_mem_rd,
    input  wire       ex_mem_reg_write,

    //--------------------------------------------------
    // Destination Register from MEM/WB
    //--------------------------------------------------
    input  wire [4:0] mem_wb_rd,
    input  wire       mem_wb_reg_write,

    //--------------------------------------------------
    // Outputs
    //--------------------------------------------------
    output reg [1:0] forward_a,
    output reg [1:0] forward_b
);

always @(*)
begin

    //--------------------------------------------------
    // Default: No Forwarding
    //--------------------------------------------------

    forward_a = 2'b00;
    forward_b = 2'b00;

    //--------------------------------------------------
    // EX Hazard (Highest Priority)
    //--------------------------------------------------

    if (ex_mem_reg_write &&
        (ex_mem_rd != 5'd0) &&
        (ex_mem_rd == id_ex_rs1))
    begin
        forward_a = 2'b10;
    end

    if (ex_mem_reg_write &&
        (ex_mem_rd != 5'd0) &&
        (ex_mem_rd == id_ex_rs2))
    begin
        forward_b = 2'b10;
    end

    //--------------------------------------------------
    // MEM Hazard
    //--------------------------------------------------

    if (mem_wb_reg_write &&
        (mem_wb_rd != 5'd0) &&
        !(ex_mem_reg_write &&
          (ex_mem_rd != 5'd0) &&
          (ex_mem_rd == id_ex_rs1)) &&
        (mem_wb_rd == id_ex_rs1))
    begin
        forward_a = 2'b01;
    end

    if (mem_wb_reg_write &&
        (mem_wb_rd != 5'd0) &&
        !(ex_mem_reg_write &&
          (ex_mem_rd != 5'd0) &&
          (ex_mem_rd == id_ex_rs2)) &&
        (mem_wb_rd == id_ex_rs2))
    begin
        forward_b = 2'b01;
    end

end

endmodule
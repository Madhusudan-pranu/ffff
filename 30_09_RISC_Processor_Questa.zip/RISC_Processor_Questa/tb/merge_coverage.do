###############################################################################
# merge_coverage.do
#
# Merge all individual UCDB files into one coverage database
#
# Usage:
#     vcover -do tb/merge_coverage.do
#
###############################################################################

echo ""
echo "============================================================"
echo "         RISC-V Coverage Merge Started"
echo "============================================================"

#------------------------------------------------------------
# Create output directories
#------------------------------------------------------------

file mkdir coverage
file mkdir coverage/html

#------------------------------------------------------------
# Remove previous merged database
#------------------------------------------------------------

if {[file exists coverage/merged.ucdb]} {
    file delete -force coverage/merged.ucdb
}

#------------------------------------------------------------
# Collect all UCDB files
#------------------------------------------------------------

set ucdb_files [glob -nocomplain coverage/ucdb/*.ucdb]

if {[llength $ucdb_files] == 0} {
    echo ""
    echo "ERROR : No UCDB files found."
    echo "Expected location:"
    echo "    coverage/ucdb/"
    quit -code 1
}

echo ""
echo "UCDB files found : [llength $ucdb_files]"

foreach f $ucdb_files {
    echo "  $f"
}

#------------------------------------------------------------
# Merge coverage databases
#------------------------------------------------------------

eval vcover merge coverage/merged.ucdb $ucdb_files

echo ""
echo "Merged database created:"
echo "    coverage/merged.ucdb"

#------------------------------------------------------------
# Generate text report
#------------------------------------------------------------

vcover report \
    -details \
    -all \
    coverage/merged.ucdb \
    > coverage/coverage_report.txt

echo "Text report created:"
echo "    coverage/coverage_report.txt"

#------------------------------------------------------------
# Generate HTML report
#------------------------------------------------------------

catch {
    vcover report \
        -html coverage/html \
        coverage/merged.ucdb
}

echo "HTML report created:"
echo "    coverage/html/"

echo ""
echo "============================================================"
echo "      Coverage Merge Completed Successfully"
echo "============================================================"

quit -f
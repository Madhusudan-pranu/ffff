module mem_wb_reg
(
    input wire clk,
    input wire rst,

    //--------------------------------------------------
    // Data Inputs
    //--------------------------------------------------

    input wire [31:0] alu_result_in,
    input wire [31:0] memory_data_in,

    input wire [4:0] rd_in,

    //--------------------------------------------------
    // Control Inputs
    //--------------------------------------------------

    input wire reg_write_in,
    input wire mem_to_reg_in,

    //--------------------------------------------------
    // Outputs
    //--------------------------------------------------

    output reg [31:0] alu_result_out,
    output reg [31:0] memory_data_out,

    output reg [4:0] rd_out,

    output reg reg_write_out,
    output reg mem_to_reg_out,
	input  [31:0] pc_in,
    output reg [31:0] pc_out,
	
	input  [31:0] instruction_in,
    output reg [31:0] instruction_out
);

always @(posedge clk)
begin

    if(rst)
    begin

        alu_result_out <= 32'd0;
        memory_data_out <= 32'd0;

        rd_out <= 5'd0;

        reg_write_out <= 1'b0;
        mem_to_reg_out <= 1'b0;

    end

    else
    begin

        alu_result_out <= alu_result_in;
        memory_data_out <= memory_data_in;

        rd_out <= rd_in;

        reg_write_out <= reg_write_in;
        mem_to_reg_out <= mem_to_reg_in;

    end

end

always @(posedge clk) begin

    if (rst) begin

        instruction_out <= 32'b0;
        pc_out          <= 32'b0;
    end
    else begin

        instruction_out <= instruction_in;
        pc_out          <= pc_in;
    end

end

endmodule
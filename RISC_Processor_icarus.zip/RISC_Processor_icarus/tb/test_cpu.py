# ###############################################################################
# # test_cpu.py
# ###############################################################################

# import cocotb

# from cocotb.clock import Clock
# from cocotb.triggers import RisingEdge
# from cocotb.triggers import Timer

# from cpu_monitor import CPUMonitor
# from cpu_reference_model import CPUReferenceModel
# from cpu_scoreboard import CPUScoreboard

# from cpu_coverage import sample_coverage


# ###############################################################################
# # Reset
# ###############################################################################

# async def reset_dut(dut):

    # dut.rst.value = 1

    # for _ in range(5):
        # await RisingEdge(dut.clk)

    # dut.rst.value = 0

    # dut._log.info("--------------------------------")
    # dut._log.info("Reset Released")
    # dut._log.info("--------------------------------")


# ###############################################################################
# # Main Test
# ###############################################################################

# @cocotb.test()
# async def cpu_smoke_test(dut):

    # ###########################################################################
    # # Clock
    # ###########################################################################

    # cocotb.start_soon(Clock(dut.clk, 10, units="ns").start())

    # ###########################################################################
    # # Banner
    # ###########################################################################

    # dut._log.info("")
    # dut._log.info("==========================================")
    # dut._log.info("     RISC-V CPU TOP LEVEL TEST")
    # dut._log.info("==========================================")

    # ###########################################################################
    # # Reset
    # ###########################################################################

    # dut._log.info("----------------------------------------")
    # dut._log.info("Applying Reset")
    # dut._log.info("----------------------------------------")

    # await reset_dut(dut)

    # ###########################################################################
    # # Components
    # ###########################################################################

    # monitor = CPUMonitor(dut)

    # reference_model = CPUReferenceModel()

    # scoreboard = CPUScoreboard(dut)

    # cocotb.start_soon(monitor.run())

    # ###########################################################################
    # # Simulation
    # ###########################################################################

    # cycle = 0
    # MAX_CYCLES = 200

    # while cycle < MAX_CYCLES:

        # await RisingEdge(dut.clk)

        # ###############################################################
        # # Coverage
        # ###############################################################

        # try:

            # sample_coverage(
                # dut.if_instruction.value.integer
            # )

        # except:

            # pass

        # ###############################################################
        # # Retired Transactions
        # ###############################################################

        # # while len(monitor.transactions) > 0:

            # # actual_txn = monitor.transactions.pop(0)

            # # expected_txn = reference_model.execute(actual_txn)

            # # scoreboard.compare(
                # # expected_txn,
                # # actual_txn
            # # )
        
        # ###############################################################

        # cycle += 1

    # ###########################################################################
    # # Finish
    # ###########################################################################

    # scoreboard.report()

    # dut._log.info("")
    # dut._log.info("==========================================")
    # dut._log.info("Simulation Finished")
    # dut._log.info("==========================================")


###############################################################################
# test_cpu.py
###############################################################################

import cocotb

from cocotb.clock import Clock
from cocotb.triggers import RisingEdge

from cpu_driver import CPUDriver
from cpu_monitor import CPUMonitor
from cpu_scoreboard import CPUScoreboard
from cpu_reference_model import CPUReferenceModel


###############################################################################
# Reset
###############################################################################

async def reset_dut(dut):

    dut._log.info("----------------------------------------")
    dut._log.info("Applying Reset")
    dut._log.info("----------------------------------------")

    #
    # Modify these signal names if your RTL uses
    # rst
    # resetn
    # rst_n
    #

    dut.rst.value = 1

    for _ in range(5):
        await RisingEdge(dut.clk)

    dut.rst.value = 0

    dut._log.info("----------------------------------------")
    dut._log.info("Reset Released")
    dut._log.info("----------------------------------------")

def print_cpu_state(dut, cycle):

    dut._log.info("--------------------------------------------------")
    dut._log.info(f"Cycle : {cycle}")
    dut._log.info("--------------------------------------------------")

    try:
        dut._log.info(f"PC           : 0x{int(dut.pc_current.value):08X}")
        dut._log.info(f"Instruction  : 0x{int(dut.if_instruction.value):08X}")
        dut._log.info(f"ID Instruction : 0x{int(dut.id_instruction.value):08X}")
        dut._log.info(f"ALU Result   : 0x{int(dut.alu_result.value):08X}")
        dut._log.info(f"WB Data      : 0x{int(dut.wb_data.value):08X}")
    except Exception:
        dut._log.warning("Some internal signals are not visible.")
        

def run_basic_checks(dut):

    try:
        assert dut.pc_current.value.integer % 4 == 0, "PC Alignment Error"
    except Exception:
        pass

    try:
        assert dut.wb_rd.value.integer < 32, "Invalid WB Register"
    except Exception:
        pass

    try:
        assert dut.ex_rs1.value.integer < 32
    except Exception:
        pass

    try:
        assert dut.ex_rs2.value.integer < 32
    except Exception:
        pass
        
###############################################################################
# Main Test
###############################################################################

@cocotb.test()

async def cpu_smoke_test(dut):

    dut._log.info("")
    dut._log.info("==========================================")
    dut._log.info("     RISC-V CPU TOP LEVEL TEST")
    dut._log.info("==========================================")

    ###########################################################################
    # Clock
    ###########################################################################

    cocotb.start_soon(
        Clock(dut.clk, 10, units="ns").start()
    )

    ###########################################################################
    # Reset
    ###########################################################################

    await reset_dut(dut)

    ###########################################################################
    # Components
    ###########################################################################

    ##############################################################
    # Verification Components
    ##############################################################
    
    driver = CPUDriver(dut)
    
    monitor = CPUMonitor(dut)
    
    reference_model = CPUReferenceModel()
    
    scoreboard = CPUScoreboard(dut)

    ###########################################################################
    # Start Monitor
    ###########################################################################

    cocotb.start_soon(
        monitor.run()
    )

    ###########################################################################
    # Run Simulation
    ###########################################################################

    #
    # Allow enough cycles for
    #
    # IF
    # ID
    # EX
    # MEM
    # WB
    #
    # plus program completion.
    #
    # Increase this number for longer programs.
    #

    MAX_SIM_CYCLES = 30

    for cycle in range(MAX_SIM_CYCLES):

        await RisingEdge(dut.clk)
        
        print_cpu_state(dut, cycle)
        
        run_basic_checks(dut)

    ##########################################################
    # Scoreboard
    ##########################################################

    # while len(monitor.wb_transactions):

        # actual_txn = monitor.wb_transactions.pop(0)

        # expected_txn = reference_model.execute(actual_txn)

        # scoreboard.compare(expected_txn, actual_txn)
    
    while len(monitor.transactions):

        actual_txn = monitor.transactions.pop(0)
        
        expected_txn = reference_model.execute(actual_txn)
        
        scoreboard.compare(expected_txn, actual_txn)

    ##########################################################
    # Coverage
    ##########################################################

    opcode = int(dut.if_instruction.value) & 0x7F

    sample_coverage(
        opcode,
        int(dut.alu_op.value),
        int(dut.branch_taken.value),
        int(dut.mem_read.value),
        int(dut.mem_write.value)
    )

    ###########################################################################
    # Stop Monitor
    ###########################################################################

    dut._log.info("")
    dut._log.info("----------------------------------------")
    dut._log.info("Simulation Completed")
    dut._log.info("----------------------------------------")

    ###########################################################################
    # Retired Instructions
    ###########################################################################

    dut._log.info("")
    dut._log.info(
        f"Total Retired Instructions = {len(monitor.transactions)}"
    )

    ###########################################################################
    # Scoreboard
    ###########################################################################

    # for txn in monitor.transactions:

        # scoreboard.compare(txn)

    ###########################################################################
    # Summary
    ###########################################################################
    dut._log.info("Regression Completed")
    
    scoreboard.report()

    ###########################################################################
    # Fail Test if Needed
    ###########################################################################

    assert scoreboard.fail_count == 0, \
        f"{scoreboard.fail_count} mismatches found."    
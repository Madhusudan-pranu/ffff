###############################################################################
# File Name : cpu_driver.py
#
# Description:
#   Driver class for the RISC-V CPU Cocotb Verification Environment.
#
# Responsibilities:
#   - Reset DUT
#   - Run CPU for N cycles
#   - Wait for PC values
#   - Wait for Writeback events
#   - Load Instruction Memory (future extension)
#
###############################################################################

import cocotb

from cocotb.triggers import RisingEdge
from cocotb.triggers import FallingEdge
from cocotb.triggers import Timer


class CPUDriver:

    ###########################################################################
    # Constructor
    ###########################################################################

    def __init__(self, dut):

        self.dut = dut

    ###########################################################################
    # Reset DUT
    ###########################################################################

    async def reset(self):

        self.dut._log.info("")
        self.dut._log.info("===================================")
        self.dut._log.info("Applying Reset")
        self.dut._log.info("===================================")

        self.dut.rst.value = 1

        for _ in range(5):

            await RisingEdge(self.dut.clk)

        self.dut.rst.value = 0

        await RisingEdge(self.dut.clk)

        self.dut._log.info("Reset Complete")

    ###########################################################################
    # Run CPU
    ###########################################################################

    async def run_cycles(self, cycles):

        self.dut._log.info("")
        self.dut._log.info(f"Running {cycles} clock cycles")

        for _ in range(cycles):

            await RisingEdge(self.dut.clk)

    ###########################################################################
    # Wait until PC reaches an address
    ###########################################################################

    async def wait_for_pc(self,
                          expected_pc,
                          timeout=500):

        self.dut._log.info(
            f"Waiting for PC = 0x{expected_pc:08X}"
        )

        for cycle in range(timeout):

            await RisingEdge(self.dut.clk)

            try:

                current_pc = int(
                    self.dut.pc_current.value
                )

                if current_pc == expected_pc:

                    self.dut._log.info(
                        f"PC reached 0x{expected_pc:08X}"
                    )

                    return

            except Exception:

                pass

        raise cocotb.result.TestFailure(
            f"Timeout waiting for PC = 0x{expected_pc:08X}"
        )

    ###########################################################################
    # Wait until a register write occurs
    ###########################################################################

    async def wait_for_writeback(self,
                                 timeout=500):

        self.dut._log.info(
            "Waiting for Register Writeback..."
        )

        for _ in range(timeout):

            await RisingEdge(self.dut.clk)

            try:

                if self.dut.wb_reg_write.value.integer:

                    rd = int(self.dut.wb_rd.value)

                    data = int(self.dut.wb_data.value)

                    self.dut._log.info(

                        f"Writeback : "
                        f"x{rd} <= "
                        f"0x{data:08X}"

                    )

                    return rd, data

            except Exception:

                pass

        raise cocotb.result.TestFailure(
            "Writeback Timeout"
        )

    ###########################################################################
    # Wait until Memory Read
    ###########################################################################

    async def wait_for_memory_read(self,
                                   timeout=500):

        for _ in range(timeout):

            await RisingEdge(self.dut.clk)

            try:

                if self.dut.mem_mem_read.value.integer:

                    self.dut._log.info(

                        f"Memory Read"

                    )

                    return

            except Exception:

                pass

        raise cocotb.result.TestFailure(
            "Memory Read Timeout"
        )

    ###########################################################################
    # Wait until Memory Write
    ###########################################################################

    async def wait_for_memory_write(self,
                                    timeout=500):

        for _ in range(timeout):

            await RisingEdge(self.dut.clk)

            try:

                if self.dut.mem_mem_write.value.integer:

                    self.dut._log.info(

                        f"Memory Write"

                    )

                    return

            except Exception:

                pass

        raise cocotb.result.TestFailure(
            "Memory Write Timeout"
        )

    ###########################################################################
    # Wait until Branch Taken
    ###########################################################################

    async def wait_for_branch(self,
                              timeout=500):

        for _ in range(timeout):

            await RisingEdge(self.dut.clk)

            try:

                if self.dut.branch_taken.value.integer:

                    pc = int(self.dut.pc_current.value)

                    self.dut._log.info(

                        f"Branch Taken @ "
                        f"PC = 0x{pc:08X}"

                    )

                    return

            except Exception:

                pass

        raise cocotb.result.TestFailure(
            "Branch Timeout"
        )

    ###########################################################################
    # Display Register Writeback
    ###########################################################################

    def display_writeback(self):

        try:

            if self.dut.wb_reg_write.value.integer:

                rd = int(self.dut.wb_rd.value)

                data = int(self.dut.wb_data.value)

                self.dut._log.info(

                    f"WB : x{rd} <= 0x{data:08X}"

                )

        except Exception:

            pass

    ###########################################################################
    # Future Program Loader
    ###########################################################################

    async def load_program(self,
                           filename):

        self.dut._log.info("")
        self.dut._log.info(
            f"Loading Program : {filename}"
        )

        #
        # Future Implementation
        #
        # Read HEX file
        # Load Instruction Memory
        #
        # Example:
        #
        # with open(filename) as f:
        #
        #     ...
        #

        self.dut._log.info(
            "Program Loader Placeholder"
        )

    ###########################################################################
    # Future Register Initialization
    ###########################################################################

    async def initialize_registers(self):

        self.dut._log.info(

            "Register Initialization Placeholder"

        )

    ###########################################################################
    # Future Data Memory Initialization
    ###########################################################################

    async def initialize_memory(self):

        self.dut._log.info(

            "Memory Initialization Placeholder"

        )
###############################################################################
# File Name : test_cpu.py
#
# Description:
#   Cocotb Testbench for a 5-Stage RISC-V CPU
#
# Author:
#   OpenAI + Madhusudan
#
###############################################################################

import cocotb
import logging

from cocotb.clock import Clock
from cocotb.triggers import RisingEdge
from cocotb.triggers import FallingEdge
from cocotb.triggers import Timer
from cpu_driver import CPUDriver
from cpu_monitor import CPUMonitor
from cpu_reference_model import CPUReferenceModel
from cpu_scoreboard import CPUScoreboard
from cocotb_coverage.coverage import coverage_db
from cpu_coverage import sample_coverage

###############################################################################
# Global Parameters
###############################################################################

CLOCK_PERIOD_NS = 10
MAX_SIM_CYCLES  = 500
#driver = CPUDriver(dut)

###############################################################################
# Logger Configuration
###############################################################################

logger = logging.getLogger("CPU_TEST")

logger.setLevel(logging.INFO)

file_handler = logging.FileHandler("simulation.log", mode="w")

formatter = logging.Formatter(
    "%(asctime)s - %(levelname)s - %(message)s"
)

file_handler.setFormatter(formatter)

logger.addHandler(file_handler)


###############################################################################
# Reset
###############################################################################

async def reset_dut(dut):

    dut._log.info("----------------------------------------")
    dut._log.info("Applying Reset")
    dut._log.info("----------------------------------------")

    dut.rst.value = 1

    for _ in range(5):
        await RisingEdge(dut.clk)

    dut.rst.value = 0

    await RisingEdge(dut.clk)

    dut._log.info("Reset Released")


###############################################################################
# Print CPU Status
###############################################################################

def print_cpu_state(dut, cycle):

    dut._log.info("--------------------------------------------------")
    dut._log.info(f"Cycle : {cycle}")
    dut._log.info("--------------------------------------------------")

    try:

        dut._log.info(
            f"PC           : 0x{int(dut.pc_current.value):08X}"
        )

        dut._log.info(
            f"Instruction  : 0x{int(dut.if_instruction.value):08X}"
        )

        dut._log.info(
            f"ID Instruction : 0x{int(dut.id_instruction.value):08X}"
        )

        dut._log.info(
            f"ALU Result   : 0x{int(dut.alu_result.value):08X}"
        )

        dut._log.info(
            f"WB Data      : 0x{int(dut.wb_data.value):08X}"
        )

    except Exception:

        dut._log.warning(
            "Some internal signals are not visible."
        )


###############################################################################
# Basic Assertions
###############################################################################

def run_basic_checks(dut):

    try:

        assert (
            dut.pc_current.value.integer % 4 == 0
        ), "PC Alignment Error"

    except Exception:

        pass

    try:

        assert (
            dut.wb_rd.value.integer < 32
        ), "WB Register Address Invalid"

    except Exception:

        pass

    try:

        assert (
            dut.ex_rs1.value.integer < 32
        )

    except Exception:

        pass

    try:

        assert (
            dut.ex_rs2.value.integer < 32
        )

    except Exception:

        pass


###############################################################################
# Main Smoke Test
###############################################################################

@cocotb.test()
async def cpu_smoke_test(dut):

    dut._log.info("")
    dut._log.info("==========================================")
    dut._log.info("     RISC-V CPU TOP LEVEL TEST")
    dut._log.info("==========================================")

    ##############################################################
    # Clock
    ##############################################################

    cocotb.start_soon(

        Clock(
            dut.clk,
            CLOCK_PERIOD_NS,
            units="ns"
        ).start()

    )

    ##############################################################
    # Reset
    ##############################################################

    await reset_dut(dut)
    
    ##############################################################
    # Create Verification Components
    ##############################################################
    
    monitor = CPUMonitor(dut)
    
    reference = CPUReferenceModel()
    
    scoreboard = CPUScoreboard()
    
    ##############################################################
    # Start Monitor
    ##############################################################
    
    cocotb.start_soon(
        monitor.run()
    )

    ##############################################################
    # Run CPU
    ##############################################################

    for cycle in range(MAX_SIM_CYCLES):

        await RisingEdge(dut.clk)

    ###################################################################
    # Feed current instruction into Reference Model
    ###################################################################

        instruction = dut.if_instruction.value.integer
        pc = dut.pc_current.value.integer
        expected_txn = reference.cycle(instruction, pc)
        
        if expected_txn is not None:
            scoreboard.add_expected(expected_txn)
      
    ###################################################################
    # Get completed transaction from Monitor
    ###################################################################

        if len(monitor.transactions):
    
            actual_txn = monitor.transactions.pop(0)
    
            scoreboard.add_actual(actual_txn)
    ###################################################################
    # Compare only when both queues contain transactions
    ###################################################################
        expected_txn = reference.cycle(instruction, pc)

        if expected_txn is not None and expected_txn.wb_enable:
            scoreboard.add_expected(expected_txn)
        
        while monitor.transactions:
            actual_txn = monitor.transactions.pop(0)
            scoreboard.add_actual(actual_txn)
        
    #    scoreboard.compare()
        scoreboard.compare()
        
    ###################################################################
    # Debug
    ###################################################################

        print_cpu_state(dut, cycle)

        run_basic_checks(dut)

    ###################################################################
    # Coverage
    ###################################################################

        dut._log.info(
            f"Sampling coverage: opcode=0x{instruction & 0x7F:02X}"
        )
        
        sample_coverage(
            dut.opcode.value.integer,
            dut.ex_alu_ctrl.value.integer,
            dut.branch_taken.value.integer,
            dut.mem_mem_read.value.integer,
            dut.mem_mem_write.value.integer
        )
    print("Coverage sampled")
    
    coverage_db.report_coverage(print)    
    coverage_db.export_to_xml("coverage.xml")
    coverage_db.export_to_yaml(
        filename="coverage.yaml"
    )
    
    
    # opcode = dut.if_instruction.value.integer & 0x7F

    # dut._log.info(f"Sampling opcode = 0x{opcode:02X}")
    
    # sample_coverage(
        # opcode,
        # dut.alu_control.value.integer,
        # dut.branch_taken.value.integer,
        # dut.mem_read.value.integer,
        # dut.mem_write.value.integer
    # )
    
    #coverage_db.report_coverage(print)
    
    logger.info("Regression Completed")
    ##############################################################
    # Scoreboard Report
    ##############################################################
    scoreboard.report()
    
    coverage_db.report_coverage(print)
    
    dut._log.info("Coverage report generated.")
    dut._log.info("")
    dut._log.info("==========================================")
    dut._log.info("Simulation Finished")
    dut._log.info("==========================================")
    
    ###############################################################
    #               Coverage Report                               
    ############################################################### 
    # while True:

        # await RisingEdge(dut.clk)
        
        # opcode = dut.if_instruction.value.integer & 0x7F
        
        # sample_coverage(
            # opcode,
            # dut.alu_control.value.integer,
            # dut.branch_taken.value.integer,
            # dut.mem_read.value.integer,
            # dut.mem_write.value.integer
        # )
    
    # coverage_db.report_coverage(print)

    # coverage_db.export_to_xml("coverage.xml")
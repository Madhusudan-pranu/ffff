Date 07/08/2026: C MADHUSUDAN.

This project is having RISC-V processor of 5-stage pipelined architecture.
In this project regression test is running with 27 different test case files.
All the test case corresponding wave files are stored in the Wave folder.
The wave files are stored only when there is failure occur in the test case log file. 
If the test case is fail we cannot save the waveform.(Even this also need to provide as an option).
Coverage is enabled but not able to store the UCDB files to merge and covert into the text and HTML format.

Date 21/08/2026: C MADHUSUDAN.
Note: Coverage is saved after elaboration stage. due to that coverage report is showing 0% for all the RTL files.
Coverage in Questa simulator using COCTB environment is working fine.
To get the coverage report. please run below commands in virtual environment.
1. make regression_cov
2. make merge_cov
3. make coverage_report.


Date 25/08/2026: C MADHUSUDAN.
Coverage in Questa simulator using COCTB environment is working fine.
To get the coverage report. please run below commands in virtual environment.
1. make regression_cov
2. make merge_cov
3. make coverage_report.

Date 04/09/2026: C MADHUSUDAN

8-bit Counter logic is added and instantiated in the CPU_TOP.v module with soft reset.
we can inject the error in the DUT and Cross verified with scoreboard comparison.
To give the soft reset use the command as "make SOFT_RESET=1" Then the DUT counter will be in zero always but the reference design will increment properly.

Date: 16/09/2026 C MADHUSUDAN
The Error messages in the transcript window is removed.
Some Failures are getting in the regression testing.
COverage is also working fully.

Date: 24/09/2026 C MADHUSUDAN
Counter Logic is moved as a saperate test case in the RISC-V 5 stage pipelined processor.
Reference design is updated for all the different king of operation.
Counter test case file is also added to the Program folder
verified by injecting the error in the design and verifying the Verification environment is working properly or not.
all the failure are removed from the regression testing.

Date: 30/09/2026 C MADHUSUDAN
Update the counter as independent test case and running independently from the Processor operation.
resolved the timestamp printing on the log file for scorebaord comparison is resolved.
test case no 29 is belongs to independent free running counter.

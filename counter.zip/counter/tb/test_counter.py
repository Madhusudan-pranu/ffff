import cocotb
from cocotb.clock import Clock
from cocotb.triggers import RisingEdge

@cocotb.test()
async def counter_test(dut):

    cocotb.start_soon(
        Clock(dut.clk, 10, units="ns").start()
    )

    dut.rst.value = 1

    for _ in range(2):
        await RisingEdge(dut.clk)

    dut.rst.value = 0

    for i in range(20):
        await RisingEdge(dut.clk)
        dut._log.info(f"Count = {int(dut.count.value)}")
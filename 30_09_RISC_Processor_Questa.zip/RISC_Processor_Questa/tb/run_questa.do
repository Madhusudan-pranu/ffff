###############################################################################
# run_questa.do
# RISC-V Cocotb Simulation Script
###############################################################################

echo ""
echo "======================================================="
echo "      Starting Questa Simulation"
echo "======================================================="

#----------------------------------------------------------
# Create waveform database
#----------------------------------------------------------

quietly set TESTNAME $env(WAVE)

if {$TESTNAME == ""} {
    set TESTNAME "default"
}

set WLF_FILE "waves/${TESTNAME}.wlf"

echo "Waveform : $WLF_FILE"

dataset open $WLF_FILE

#----------------------------------------------------------
# Log everything
#----------------------------------------------------------

log -r /*

#----------------------------------------------------------
# Run simulation
#----------------------------------------------------------

run -all

#----------------------------------------------------------
# Save coverage
#----------------------------------------------------------

file mkdir coverage
file mkdir coverage/ucdb

set UCDB_FILE "coverage/ucdb/${TESTNAME}.ucdb"

echo "Saving coverage to $UCDB_FILE"

coverage save $UCDB_FILE

#----------------------------------------------------------
# Close waveform
#----------------------------------------------------------

dataset close

echo ""
echo "Simulation Finished."

quit -f
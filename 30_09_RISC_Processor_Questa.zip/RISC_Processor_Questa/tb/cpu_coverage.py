from cocotb_coverage.coverage import coverage_section
from cocotb_coverage.coverage import CoverPoint
from cocotb_coverage.coverage import coverage_db


class CPUCoverage:

    def __init__(self):
        pass

    @CoverPoint("cpu.opcode",
                xf=lambda pc, instruction, opcode,
                          alu_result, branch,
                          mem_read, mem_write,
                          reg_write: opcode,
                bins=[0x03,0x13,0x17,0x23,0x33,0x37,0x63,0x67,0x6F])

    @CoverPoint("cpu.branch",
                xf=lambda pc, instruction, opcode,
                          alu_result, branch,
                          mem_read, mem_write,
                          reg_write: branch,
                bins=[0,1])

    @CoverPoint("cpu.mem_read",
                xf=lambda pc, instruction, opcode,
                          alu_result, branch,
                          mem_read, mem_write,
                          reg_write: mem_read,
                bins=[0,1])

    @CoverPoint("cpu.mem_write",
                xf=lambda pc, instruction, opcode,
                          alu_result, branch,
                          mem_read, mem_write,
                          reg_write: mem_write,
                bins=[0,1])

    @CoverPoint("cpu.reg_write",
                xf=lambda pc, instruction, opcode,
                          alu_result, branch,
                          mem_read, mem_write,
                          reg_write: reg_write,
                bins=[0,1])

    def sample_coverage(self,
               pc,
               instruction,
               opcode,
               alu_result,
               branch,
               mem_read,
               mem_write,
               reg_write):

        pass

    def report(self):

    coverage_db.report_coverage(
        dut._log.info,
        bins=True,
        node="cpu"
    )
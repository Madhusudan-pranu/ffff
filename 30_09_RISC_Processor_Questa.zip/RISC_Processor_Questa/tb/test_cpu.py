###############################################################################
# test_cpu.py
###############################################################################
import os
import cocotb

from cocotb.clock import Clock
from cocotb.triggers import RisingEdge, ReadOnly

from cpu_driver import CPUDriver
from cpu_monitor import CPUMonitor
from cpu_scoreboard import CPUScoreboard
from cpu_reference_model import CPUReferenceModel
from cocotb_coverage.coverage import CoverPoint
from cocotb_coverage.coverage import coverage_db

###############################################################################
# Reset
###############################################################################

async def reset_dut(dut):

    dut._log.info("----------------------------------------")
    dut._log.info("Applying Reset")
    dut._log.info("----------------------------------------")

    # Modify these signal names if your RTL uses

    dut.rst.value = 1

    for _ in range(5):
        await RisingEdge(dut.clk)

    dut.rst.value = 0

    dut._log.info("----------------------------------------")
    dut._log.info("Reset Released")
    dut._log.info("----------------------------------------")
    
async def soft_reset_dut(dut):

    dut._log.info("----------------------------------------")
    dut._log.info("Applying Soft Reset")
    dut._log.info("----------------------------------------")

    soft_reset = int(os.getenv("SOFT_RESET", "0"))
    if hasattr(dut, 'soft_rst'):
        dut.soft_rst.value = soft_reset
        
def print_cpu_state(dut, cycle):

    dut._log.info("--------------------------------------------------")
    dut._log.info(f"Cycle : {cycle}")
    dut._log.info("--------------------------------------------------")

    try:
        dut._log.info(f"PC           : 0x{int(dut.pc_current.value):08X}")
        dut._log.info(f"Instruction  : 0x{int(dut.if_instruction.value):08X}")
        dut._log.info(f"ID Instruction : 0x{int(dut.id_instruction.value):08X}")
        dut._log.info(f"ALU Result   : 0x{int(dut.alu_result.value):08X}")
        dut._log.info(f"WB Data      : 0x{int(dut.wb_data.value):08X}")
    except Exception:
        dut._log.warning("Some internal signals are not visible.")
        

def run_basic_checks(dut):

    try:
        assert dut.pc_current.value.integer % 4 == 0, "PC Alignment Error"
    except Exception:
        pass

    try:
        assert dut.wb_rd.value.integer < 32, "Invalid WB Register"
    except Exception:
        pass

    try:
        assert dut.ex_rs1.value.integer < 32
    except Exception:
        pass

    try:
        assert dut.ex_rs2.value.integer < 32
    except Exception:
        pass

###########################################################################
# Functional Coverage
###########################################################################

@CoverPoint(
    "cpu.opcode",
    xf=lambda pc, instruction, opcode,
              alu_result, branch,
              mem_read, mem_write,
              reg_write: opcode,
    bins=[0x03, 0x13, 0x17, 0x23, 0x33, 0x37, 0x63, 0x67, 0x6F]
)
@CoverPoint(
    "cpu.branch",
    xf=lambda pc, instruction, opcode,
              alu_result, branch,
              mem_read, mem_write,
              reg_write: branch,
    bins=[0, 1]
)
@CoverPoint(
    "cpu.mem_read",
    xf=lambda pc, instruction, opcode,
              alu_result, branch,
              mem_read, mem_write,
              reg_write: mem_read,
    bins=[0, 1]
)
@CoverPoint(
    "cpu.mem_write",
    xf=lambda pc, instruction, opcode,
              alu_result, branch,
              mem_read, mem_write,
              reg_write: mem_write,
    bins=[0, 1]
)
@CoverPoint(
    "cpu.reg_write",
    xf=lambda pc, instruction, opcode,
              alu_result, branch,
              mem_read, mem_write,
              reg_write: reg_write,
    bins=[0, 1]
)
def sample_coverage(
    pc,
    instruction,
    opcode,
    alu_result,
    branch,
    mem_read,
    mem_write,
    reg_write
):
    pass
    
###############################################################################
# Main Test
###############################################################################

@cocotb.test()
async def cpu_smoke_test(dut):

    dut._log.info("")
    dut._log.info("==========================================")
    dut._log.info("     RISC-V CPU TOP LEVEL TEST")
    dut._log.info("==========================================")

    ###########################################################################
    # Clock
    ###########################################################################
    clock_period = int(os.getenv("CLOCK_PERIOD", "10"))
    
    cocotb.start_soon(
        Clock(dut.clk, clock_period, units="ns").start()
    )

    ###########################################################################
    # Reset
    ###########################################################################

    await reset_dut(dut)
    await soft_reset_dut(dut)

    ##############################################################
    # Verification Components
    ##############################################################
    
    driver = CPUDriver(dut)
    monitor = CPUMonitor(dut)
    reference_model = CPUReferenceModel()
    scoreboard = CPUScoreboard(dut)

    ###########################################################################
    # Start Monitor
    ###########################################################################

    cocotb.start_soon(
        monitor.run()
    )

    ###########################################################################
    # Run Simulation
    ###########################################################################

    MAX_SIM_CYCLES = 30

    for cycle in range(MAX_SIM_CYCLES):

        await RisingEdge(dut.clk)
        
        actual_count = monitor.get_dut_counter()
        
        print_cpu_state(dut, cycle)
        
        run_basic_checks(dut)
             
        scoreboard.compare_counter(
            monitor.reference_count,
            actual_count
        )
        
        # Pop and compare any transaction that completed during this cycle
        while len(monitor.transactions) > 0:
            actual_txn = monitor.transactions.pop(0)
            expected_txn = reference_model.execute(actual_txn)
            scoreboard.compare(expected_txn, actual_txn)

    ##########################################################
    # Coverage
    ##########################################################
    sample_coverage(
        dut.pc_current.value.integer,
        dut.if_instruction.value.integer,
        dut.if_instruction.value.integer & 0x7F,
        dut.alu_result.value.integer,
        dut.branch_taken.value.integer,
        dut.mem_mem_read.value.integer,
        dut.mem_mem_write.value.integer,
        dut.wb_reg_write.value.integer
    )

    ###########################################################################
    # Stop Monitor
    ###########################################################################

    dut._log.info("")
    dut._log.info("----------------------------------------")
    dut._log.info("Simulation Completed")
    dut._log.info("----------------------------------------")

    ###########################################################################
    # Summary
    ###########################################################################
    dut._log.info("Regression Completed")
    
    scoreboard.report()
    
    dut._log.info("")
    dut._log.info("========== FUNCTIONAL COVERAGE ==========")
    
    coverage_db.report_coverage(
        dut._log.info,
        bins=True,
        node="cpu"
    )
    
    coverage_db.export_to_xml("coverage/html/function_coverage.xml")
    coverage_db.export_to_yaml("coverage/html/function_coverage.yml")

    ###########################################################################
    # Fail Test if Needed
    ###########################################################################

    assert scoreboard.fail_count == 0, \
        f"{scoreboard.fail_count} mismatches found."
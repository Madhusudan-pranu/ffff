#!/usr/bin/env python3
###############################################################################
# RISC-V Processor Regression Runner
#
# Simulator : Questa FSE 2025.2
# Cocotb    : 1.9.2
#
# Purpose:
#   1. Compile RTL once
#   2. Run every RISC-V program individually
#   3. Generate one WLF per testcase
#   4. Generate one UCDB per testcase
#   5. Generate individual logs
#   6. Merge coverage
#   7. Generate text and HTML coverage reports
###############################################################################

import os
import sys
import shutil
import subprocess
from pathlib import Path
from datetime import datetime


###############################################################################
# Project paths
###############################################################################

ROOT_DIR = Path(__file__).resolve().parent.parent

RTL_DIR = ROOT_DIR / "rtl"
TB_DIR = ROOT_DIR / "tb"

PROGRAM_DIR = ROOT_DIR / "programs"

SCRIPT_DIR = ROOT_DIR / "scripts"

LOG_DIR = ROOT_DIR / "logs"
WAVE_DIR = ROOT_DIR / "waves"

COVERAGE_DIR = ROOT_DIR / "coverage"
UCDB_DIR = COVERAGE_DIR / "ucdb"
HTML_DIR = COVERAGE_DIR / "html"

SIM_BUILD_DIR = ROOT_DIR / "sim_build"

WORK_DIR = SIM_BUILD_DIR / "work"

COMPILE_DO = SCRIPT_DIR / "compile.do"
RUN_DO = SCRIPT_DIR / "run.do"
MERGE_COV_DO = SCRIPT_DIR / "merge_cov.do"


###############################################################################
# Questa executable
###############################################################################

QUESTA_BIN = os.environ.get(
    "QUESTA_BIN",
    "/home/einfochips/altera/25.1std/questa_fse/bin/vsim"
)

VCOVER_BIN = os.environ.get(
    "VCOVER_BIN",
    "/home/einfochips/altera/25.1std/questa_fse/bin/vcover"
)


###############################################################################
# Regression programs
###############################################################################

REGRESSION_PROGRAMS = [
    "01_nop.hex",
    "02_addi.hex",
    "03_add.hex",
    "04_sub.hex",
    "05_and.hex",
    "06_or.hex",
    "07_xor.hex",
    "08_sll.hex",
    "09_srl.hex",
    "10_sra.hex",
    "11_slt.hex",
    "12_sltu.hex",
    "13_lui.hex",
    "14_auipc.hex",
    "15_store.hex",
    "16_load.hex",
    "17_load_store.hex",
    "18_forwarding_ex.hex",
    "19_forwarding_mem.hex",
    "20_load_use.hex",
    "21_branch_taken.hex",
    "22_branch_not_taken.hex",
    "23_jal.hex",
    "24_jalr.hex",
    "25_mixed.hex",
    "26_random.hex",
    "27_stress.hex",
]


###############################################################################
# Environment
###############################################################################

ENV = os.environ.copy()

ENV["PYTHONPATH"] = (
    str(ROOT_DIR)
    + os.pathsep
    + str(TB_DIR)
    + os.pathsep
    + ENV.get("PYTHONPATH", "")
)


###############################################################################
# Utility functions
###############################################################################

def print_header(title):
    print()
    print("=" * 78)
    print(title)
    print("=" * 78)
    print()


def run_command(command, log_file=None, cwd=ROOT_DIR, env=None):
    """
    Run a shell command.

    Returns:
        subprocess return code
    """

    print()
    print("COMMAND:")
    print(" ".join(str(x) for x in command))
    print()

    if log_file is not None:
        with open(log_file, "w") as logfile:
            result = subprocess.run(
                command,
                cwd=cwd,
                env=env,
                stdout=logfile,
                stderr=subprocess.STDOUT,
                text=True,
            )
    else:
        result = subprocess.run(
            command,
            cwd=cwd,
            env=env,
            text=True,
        )

    return result.returncode


###############################################################################
# Create directories
###############################################################################

def create_directories():

    for directory in [
        LOG_DIR,
        WAVE_DIR,
        COVERAGE_DIR,
        UCDB_DIR,
        HTML_DIR,
        SIM_BUILD_DIR,
        SCRIPT_DIR,
    ]:
        directory.mkdir(parents=True, exist_ok=True)


###############################################################################
# Check required files
###############################################################################

def check_environment():

    print_header("Checking Regression Environment")

    if not Path(QUESTA_BIN).exists():
        print(f"ERROR: Questa executable not found:")
        print(f"       {QUESTA_BIN}")
        sys.exit(1)

    if not Path(VCOVER_BIN).exists():
        print(f"ERROR: vcover executable not found:")
        print(f"       {VCOVER_BIN}")
        sys.exit(1)

    if not COMPILE_DO.exists():
        print(f"ERROR: Missing:")
        print(f"       {COMPILE_DO}")
        sys.exit(1)

    if not RUN_DO.exists():
        print(f"ERROR: Missing:")
        print(f"       {RUN_DO}")
        sys.exit(1)

    for program in REGRESSION_PROGRAMS:

        program_path = PROGRAM_DIR / program

        if not program_path.exists():
            print(f"ERROR: Missing program:")
            print(f"       {program_path}")
            sys.exit(1)

    print("Questa       : OK")
    print("vcover       : OK")
    print("compile.do   : OK")
    print("run.do       : OK")
    print("Programs     : OK")
    print()


###############################################################################
# Compile RTL
###############################################################################

def compile_design():

    print_header("Compiling RISC-V RTL")

    compile_log = LOG_DIR / "compile.log"

    # Remove previous work library.
    if WORK_DIR.exists():
        shutil.rmtree(WORK_DIR)

    WORK_DIR.mkdir(parents=True, exist_ok=True)

    command = [
        QUESTA_BIN,
        "-c",
        "-64",
        "-do",
        str(COMPILE_DO),
    ]

    returncode = run_command(
        command,
        log_file=compile_log,
    )

    if returncode != 0:

        print()
        print("ERROR: RTL compilation failed.")
        print(f"Compilation log:")
        print(f"    {compile_log}")
        print()

        return False

    print()
    print("RTL compilation successful.")
    print()

    return True


###############################################################################
# Generate temporary Questa run script
###############################################################################

def create_run_script(program, testname, ucdb_file, wlf_file):

    program_path = PROGRAM_DIR / program

    run_script = SIM_BUILD_DIR / f"run_{testname}.do"

    # Use absolute paths so the script is independent of current directory.
    program_abs = program_path.resolve()
    ucdb_abs = ucdb_file.resolve()
    wlf_abs = wlf_file.resolve()

    with open(run_script, "w") as f:

        f.write("transcript on\n")
        f.write("\n")

        f.write('echo ""\n')
        f.write(f'echo "============================================================"\n')
        f.write(f'echo "Test: {testname}"\n')
        f.write(f'echo "Program: {program_abs}"\n')
        f.write(f'echo "============================================================"\n')
        f.write("\n")

        #######################################################################
        # Load Cocotb VPI
        #######################################################################

        f.write("set COCOTB_VPI [exec cocotb-config --lib-name-path vpi questa]\n")
        f.write("\n")

        #######################################################################
        # Load DUT
        #######################################################################

        f.write("vsim -coverage -64 ")
        f.write(f"-wlf {{{wlf_abs}}} ")
        f.write("-pli $COCOTB_VPI ")
        f.write("work.cpu_top\n")
        f.write("\n")

        #######################################################################
        # Program argument
        #######################################################################

        f.write(f"set PROGRAM {{{program_abs}}}\n")
        f.write("\n")

        #######################################################################
        # Make PROGRAM available to Cocotb
        #######################################################################

        f.write(f"set ::env(PROGRAM) {{{program_abs}}}\n")
        f.write(f"set ::env(WAVE) {{{testname}}}\n")
        f.write(f"set ::env(UCDB_FILE) {{{ucdb_abs}}}\n")
        f.write(f"set ::env(WLF_FILE) {{{wlf_abs}}}\n")
        f.write("\n")

        #######################################################################
        # Log all DUT signals
        #######################################################################

        f.write("log -r /*\n")
        f.write("\n")

        #######################################################################
        # Start Cocotb
        #######################################################################

        f.write("set ::env(COCOTB_SIM) 1\n")
        f.write("\n")

        #######################################################################
        # Run simulation
        #######################################################################

        f.write("run -all\n")
        f.write("\n")

        #######################################################################
        # Save coverage
        #######################################################################

        f.write('echo ""\n')
        f.write('echo "Saving coverage database..."\n')

        f.write(
            f'coverage save {{{ucdb_abs}}}\n'
        )

        f.write("\n")

        #######################################################################
        # Verify UCDB
        #######################################################################

        f.write(
            f'if {{![file exists {{{ucdb_abs}}}]}} {{\n'
        )

        f.write(
            '    echo "ERROR: UCDB file was not created."\n'
        )

        f.write(
            '    quit -f -code 1\n'
        )

        f.write("}\n")
        f.write("\n")

        #######################################################################
        # Finish
        #######################################################################

        f.write('echo "Coverage saved successfully."\n')
        f.write("\n")

        f.write("quit -f -code 0\n")

    return run_script


###############################################################################
# Run one testcase
###############################################################################

def run_test(program):

    testname = Path(program).stem

    print()
    print("-" * 78)
    print(f"Running Test : {testname}")
    print(f"Program      : {program}")
    print("-" * 78)

    log_file = LOG_DIR / f"{testname}.log"

    wlf_file = WAVE_DIR / f"{testname}.wlf"

    ucdb_file = UCDB_DIR / f"{testname}.ucdb"

    run_script = create_run_script(
        program,
        testname,
        ucdb_file,
        wlf_file,
    )

    # Remove old outputs.
    if wlf_file.exists():
        wlf_file.unlink()

    if ucdb_file.exists():
        ucdb_file.unlink()

    command = [
        QUESTA_BIN,
        "-c",
        "-64",
        "-do",
        str(run_script),
    ]

    start_time = datetime.now()

    returncode = run_command(
        command,
        log_file=log_file,
    )

    elapsed = datetime.now() - start_time

    ###########################################################################
    # Check outputs
    ###########################################################################

    ucdb_exists = ucdb_file.exists()

    wlf_exists = wlf_file.exists()

    ###########################################################################
    # Determine result
    ###########################################################################

    passed = (
        returncode == 0
        and ucdb_exists
    )

    if passed:

        print()
        print(f"[PASS] {testname}")
        print(f"       WLF  : {wlf_file}")
        print(f"       UCDB : {ucdb_file}")
        print(f"       LOG  : {log_file}")
        print(f"       TIME : {elapsed}")
        print()

    else:

        print()
        print(f"[FAIL] {testname}")
        print(f"       Return code : {returncode}")
        print(f"       WLF exists  : {wlf_exists}")
        print(f"       UCDB exists : {ucdb_exists}")
        print(f"       LOG         : {log_file}")
        print(f"       TIME        : {elapsed}")
        print()

    # Remove temporary DO file.
    try:
        run_script.unlink()
    except FileNotFoundError:
        pass

    return passed


###############################################################################
# Merge coverage
###############################################################################

def merge_coverage():

    print_header("Merging Coverage")

    ucdb_files = sorted(UCDB_DIR.glob("*.ucdb"))

    if not ucdb_files:

        print("ERROR: No UCDB files found.")
        return False

    merged_ucdb = COVERAGE_DIR / "merged.ucdb"

    if merged_ucdb.exists():
        merged_ucdb.unlink()

    command = [
        VCOVER_BIN,
        "merge",
        "-out",
        str(merged_ucdb),
    ]

    command.extend(str(x) for x in ucdb_files)

    returncode = run_command(command)

    if returncode != 0:

        print()
        print("ERROR: Coverage merge failed.")
        return False

    if not merged_ucdb.exists():

        print()
        print("ERROR: merged.ucdb was not created.")
        return False

    print()
    print("Coverage merge successful.")
    print()
    print(f"Merged UCDB:")
    print(f"    {merged_ucdb}")
    print()

    return True


###############################################################################
# Generate coverage reports
###############################################################################

def generate_coverage_reports():

    print_header("Generating Coverage Reports")

    merged_ucdb = COVERAGE_DIR / "merged.ucdb"

    if not merged_ucdb.exists():

        print("ERROR: merged.ucdb does not exist.")
        return False

    text_report = COVERAGE_DIR / "coverage.txt"

    html_dir = HTML_DIR

    html_dir.mkdir(parents=True, exist_ok=True)

    ###########################################################################
    # Text report
    ###########################################################################

    print("Generating text coverage report...")

    command = [
        VCOVER_BIN,
        "report",
        "-details",
        str(merged_ucdb),
    ]

    with open(text_report, "w") as report:

        result = subprocess.run(
            command,
            cwd=ROOT_DIR,
            env=ENV,
            stdout=report,
            stderr=subprocess.STDOUT,
            text=True,
        )

    if result.returncode != 0:

        print("ERROR: Text coverage report failed.")
        return False

    ###########################################################################
    # HTML report
    ###########################################################################

    print("Generating HTML coverage report...")

    command = [
        VCOVER_BIN,
        "report",
        "-html",
        "-output",
        str(html_dir),
        str(merged_ucdb),
    ]

    result = subprocess.run(
        command,
        cwd=ROOT_DIR,
        env=ENV,
        text=True,
    )

    if result.returncode != 0:

        print("ERROR: HTML coverage report failed.")
        return False

    print()
    print("Coverage reports generated:")
    print()
    print(f"UCDB : {merged_ucdb}")
    print(f"TXT  : {text_report}")
    print(f"HTML : {html_dir}")
    print()

    return True


###############################################################################
# Print regression summary
###############################################################################

def print_summary(results, start_time):

    print()
    print("=" * 78)
    print("                    REGRESSION SUMMARY")
    print("=" * 78)

    total = len(results)

    passed = sum(
        1 for result in results
        if result["passed"]
    )

    failed = total - passed

    print()
    print(f"Total Tests : {total}")
    print(f"PASS        : {passed}")
    print(f"FAIL        : {failed}")

    print()
    print("-" * 78)

    for result in results:

        status = "PASS" if result["passed"] else "FAIL"

        print(
            f"{status:>6} : "
            f"{result['testname']}"
        )

    elapsed = datetime.now() - start_time

    print()
    print("-" * 78)
    print(f"Total Regression Time : {elapsed}")
    print("=" * 78)
    print()

    return failed == 0


###############################################################################
# Main regression
###############################################################################

def main():

    regression_start = datetime.now()

    print()
    print("=" * 78)
    print("              RISC-V PROCESSOR REGRESSION")
    print("=" * 78)
    print()
    print(f"Project : {ROOT_DIR}")
    print(f"Questa  : {QUESTA_BIN}")
    print()

    ###########################################################################
    # Prepare directories
    ###########################################################################

    create_directories()

    ###########################################################################
    # Check environment
    ###########################################################################

    check_environment()

    ###########################################################################
    # Compile once
    ###########################################################################

    if not compile_design():

        print()
        print("Regression aborted because compilation failed.")
        sys.exit(1)

    ###########################################################################
    # Run all tests
    ###########################################################################

    results = []

    for program in REGRESSION_PROGRAMS:

        passed = run_test(program)

        results.append(
            {
                "testname": Path(program).stem,
                "program": program,
                "passed": passed,
            }
        )

    ###########################################################################
    # Summary
    ###########################################################################

    all_passed = print_summary(
        results,
        regression_start,
    )

    ###########################################################################
    # Coverage merge
    ###########################################################################

    coverage_success = merge_coverage()

    ###########################################################################
    # Coverage report
    ###########################################################################

    report_success = False

    if coverage_success:

        report_success = generate_coverage_reports()

    ###########################################################################
    # Final result
    ###########################################################################

    print()
    print("=" * 78)
    print("                    REGRESSION COMPLETE")
    print("=" * 78)
    print()

    if all_passed:
        print("Simulation Result : PASS")
    else:
        print("Simulation Result : FAIL")

    if coverage_success:
        print("Coverage Merge    : PASS")
    else:
        print("Coverage Merge    : FAIL")

    if report_success:
        print("Coverage Report   : PASS")
    else:
        print("Coverage Report   : FAIL")

    print()
    print("=" * 78)
    print()

    ###########################################################################
    # Return failure if simulation failed.
    ###########################################################################

    if not all_passed:

        sys.exit(1)

    if not coverage_success:

        sys.exit(1)

    if not report_success:

        sys.exit(1)

    sys.exit(0)


###############################################################################
# Entry point
###############################################################################

if __name__ == "__main__":
    main()
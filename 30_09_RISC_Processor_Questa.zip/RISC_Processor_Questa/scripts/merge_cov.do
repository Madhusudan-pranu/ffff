###############################################################################
# merge_cov.do
#
# Merge all per-test UCDB files and generate coverage reports.
#
# Expected directory structure:
#
# coverage/
#   ucdb/
#       01_nop.ucdb
#       02_addi.ucdb
#       03_add.ucdb
#       ...
#   merged.ucdb
#   coverage.txt
#   html/
#
###############################################################################

transcript on

echo ""
echo "==============================================================="
echo "             RISC-V Coverage Merge"
echo "==============================================================="
echo ""

###############################################################################
# Directories
###############################################################################

set COV_DIR  "coverage"
set UCDB_DIR "coverage/ucdb"
set HTML_DIR "coverage/html"

###############################################################################
# Create HTML directory
###############################################################################

if {![file exists $COV_DIR]} {
    file mkdir $COV_DIR
}

if {![file exists $HTML_DIR]} {
    file mkdir $HTML_DIR
}

###############################################################################
# Check for UCDB files
###############################################################################

set UCDB_FILES [glob -nocomplain -directory $UCDB_DIR *.ucdb]

if {[llength $UCDB_FILES] == 0} {
    echo ""
    echo "ERROR: No UCDB files found in:"
    echo "       $UCDB_DIR"
    echo ""
    quit -code 1
}

echo "UCDB files found:"
foreach file $UCDB_FILES {
    echo "    $file"
}

echo ""

###############################################################################
# Merge UCDB files
###############################################################################

set MERGED_UCDB "$COV_DIR/merged.ucdb"

echo "Merging coverage..."
echo ""

vcover merge \
    -out $MERGED_UCDB \
    {*}$UCDB_FILES

if {![file exists $MERGED_UCDB]} {
    echo ""
    echo "ERROR: Coverage merge failed."
    echo ""
    quit -code 1
}

echo ""
echo "Merged UCDB:"
echo "    $MERGED_UCDB"

###############################################################################
# Generate detailed text report
###############################################################################

echo ""
echo "Generating text coverage report..."

vcover report \
    -details \
    $MERGED_UCDB \
    > "$COV_DIR/coverage.txt"

if {![file exists "$COV_DIR/coverage.txt"]} {
    echo ""
    echo "WARNING: Text coverage report was not generated."
} else {
    echo "Text report:"
    echo "    $COV_DIR/coverage.txt"
}

###############################################################################
# Generate HTML report
###############################################################################

echo ""
echo "Generating HTML coverage report..."

vcover report \
    -html \
    -output $HTML_DIR \
    $MERGED_UCDB

if {![file exists "$HTML_DIR"]} {
    echo ""
    echo "WARNING: HTML coverage directory was not generated."
} else {
    echo "HTML report:"
    echo "    $HTML_DIR"
}

###############################################################################
# Finish
###############################################################################

echo ""
echo "==============================================================="
echo "             Coverage Merge Completed"
echo "==============================================================="
echo ""
echo "Merged UCDB : $MERGED_UCDB"
echo "Text Report : $COV_DIR/coverage.txt"
echo "HTML Report : $HTML_DIR"
echo ""

quit -f
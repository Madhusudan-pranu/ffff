###############################################################################
# compile.do
# Compile all RTL files into the work library
###############################################################################

transcript on

if {[file exists work]} {
    vdel -all -lib work
}

vlib work
vmap work work

###############################################################################
# Enable Coverage
###############################################################################

set COVER "+cover=bcesft"
# Get the directory containing this compile.do script
set SCRIPT_DIR [file dirname [file normalize [info script]]]

# Project root is one level above tb/
set PROJECT_DIR [file normalize "$SCRIPT_DIR/.."]

puts "=============================================="
puts "Project Directory : $PROJECT_DIR"
puts "Compiling RISC-V RTL with coverage enabled"
puts "=============================================="

vlog -reportprogress 300 \
    "+cover=bcesft" \
    "+acc" \
    "+incdir+$PROJECT_DIR/rtl" \
    "$PROJECT_DIR/rtl/cpu_top.v" \
    "$PROJECT_DIR/rtl/pc.v" \
    "$PROJECT_DIR/rtl/instruction_memory.v" \
    "$PROJECT_DIR/rtl/if_id_reg.v" \
    "$PROJECT_DIR/rtl/register_file.v" \
    "$PROJECT_DIR/rtl/immediate_generator.v" \
    "$PROJECT_DIR/rtl/control_unit.v" \
    "$PROJECT_DIR/rtl/hazard_detection_unit.v" \
    "$PROJECT_DIR/rtl/id_ex_reg.v" \
    "$PROJECT_DIR/rtl/alu_control.v" \
    "$PROJECT_DIR/rtl/forwarding_unit.v" \
    "$PROJECT_DIR/rtl/branch_unit.v" \
    "$PROJECT_DIR/rtl/alu.v" \
    "$PROJECT_DIR/rtl/ex_mem_reg.v" \
    "$PROJECT_DIR/rtl/data_memory.v" \
    "$PROJECT_DIR/rtl/mem_wb_reg.v"

if {$errorCode != ""} {
    echo ""
    echo "Compilation FAILED."
    quit -code 1
}

echo ""
echo "Compilation Successful."
module cocotb_iverilog_dump();
initial begin
    $dumpfile("sim_build/cpu_top.fst");
    $dumpvars(0, cpu_top);
end
endmodule

`include "defines.v"

module control_unit
(
    input  wire [6:0] opcode,

    output reg        reg_write,
    output reg        mem_read,
    output reg        mem_write,
    output reg        mem_to_reg,
    output reg        alu_src,
    output reg        branch,
    output reg        jump,
    output reg [1:0]  alu_op
);

always @(*)
begin

    //--------------------------------------------------
    // Default Values
    //--------------------------------------------------

    reg_write = 1'b0;
    mem_read  = 1'b0;
    mem_write = 1'b0;
    mem_to_reg= 1'b0;
    alu_src   = 1'b0;
    branch    = 1'b0;
    jump      = 1'b0;
    alu_op    = 2'b00;

    case(opcode)

    //--------------------------------------------------
    // R-Type
    //--------------------------------------------------

    `OPCODE_RTYPE:
    begin
        reg_write = 1'b1;
        alu_src   = 1'b0;
        alu_op    = 2'b10;
    end

    //--------------------------------------------------
    // I-Type Arithmetic
    //--------------------------------------------------

    `OPCODE_ITYPE:
    begin
        reg_write = 1'b1;
        alu_src   = 1'b1;
        alu_op    = 2'b11;
    end

    //--------------------------------------------------
    // LOAD
    //--------------------------------------------------

    `OPCODE_LOAD:
    begin
        reg_write = 1'b1;
        mem_read  = 1'b1;
        mem_to_reg= 1'b1;
        alu_src   = 1'b1;
        alu_op    = 2'b00;
    end

    //--------------------------------------------------
    // STORE
    //--------------------------------------------------

    `OPCODE_STORE:
    begin
        mem_write = 1'b1;
        alu_src   = 1'b1;
        alu_op    = 2'b00;
    end

    //--------------------------------------------------
    // BRANCH
    //--------------------------------------------------

    `OPCODE_BRANCH:
    begin
        branch = 1'b1;
        alu_op = 2'b01;
    end

    //--------------------------------------------------
    // JAL
    //--------------------------------------------------

    `OPCODE_JAL:
    begin
        jump      = 1'b1;
        reg_write = 1'b1;
    end

    //--------------------------------------------------
    // JALR
    //--------------------------------------------------

    `OPCODE_JALR:
    begin
        jump      = 1'b1;
        reg_write = 1'b1;
        alu_src   = 1'b1;
    end

    //--------------------------------------------------
    // LUI
    //--------------------------------------------------

    `OPCODE_LUI:
    begin
        reg_write = 1'b1;
        alu_src   = 1'b1;
    end

    //--------------------------------------------------
    // AUIPC
    //--------------------------------------------------

    `OPCODE_AUIPC:
    begin
        reg_write = 1'b1;
        alu_src   = 1'b1;
    end

    default:
    begin
    end

    endcase

end

endmodule
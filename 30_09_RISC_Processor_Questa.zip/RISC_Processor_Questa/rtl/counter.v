module counter (
    input  wire        clk,
    input  wire        rst,
    input  wire        soft_rst,
    input  wire [ 6:0] opcode,
    output reg  [15:0] count
);

reg        enable;

always@(posedge clk)
    begin
    	if (rst||soft_rst)
			enable <= 1'b0;
		else if(opcode == 7'h18)
		    enable <= 1'b1;
	end
	
always @(posedge clk) begin
    if (rst||soft_rst)
        count <= 16'd0;
    else if(enable == 1'b1)	
        count <= count + 16'd1;
	else
        count <= count;	
end

endmodule
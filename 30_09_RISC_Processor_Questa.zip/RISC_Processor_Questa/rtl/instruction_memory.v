module instruction_memory
(
    input  wire [31:0] address,

    output reg [31:0] instruction
);
localparam PROGRAM_SIZE = 256;
reg [31:0] memory [0:255];
reg [1023:0] program_file;
integer i;
// assign instruction = memory[address[9:2]];

always @(*) begin
    if (address[9:2] < PROGRAM_SIZE)
        instruction = memory[address[9:2]];
    else
        instruction = 32'h00000013;   // NOP
end

initial begin
    // Initialize instruction memory with NOPs
    for (i = 0; i < 256; i = i + 1)
        memory[i] = 32'h00000013;

    // Get program filename from plusarg
    if (!$value$plusargs("PROGRAM=%s", program_file))
        program_file = "programs/03_add.hex";

    $display("Loading program: %0s", program_file);

    // Load program
    $readmemh(program_file, memory);

end

endmodule